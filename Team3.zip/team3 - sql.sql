-- --------------------------------------------------------
-- 호스트:                          220.70.33.29
-- 서버 버전:                        10.3.27-MariaDB-0+deb10u1 - Raspbian 10
-- 서버 OS:                        debian-linux-gnueabihf
-- HeidiSQL 버전:                  11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- team3 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `team3` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `team3`;

-- 테이블 team3.fcomments 구조 내보내기
CREATE TABLE IF NOT EXISTS `fcomments` (
  `f_no` int(11) NOT NULL AUTO_INCREMENT,
  `member_no` int(11) NOT NULL,
  `fboard_no` int(11) NOT NULL,
  `fcontent` varchar(500) NOT NULL DEFAULT '',
  `fdate` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`f_no`) USING BTREE,
  KEY `FK__member` (`member_no`) USING BTREE,
  KEY `FK_fboardcoments_freeboard` (`fboard_no`) USING BTREE,
  CONSTRAINT `FK__member` FOREIGN KEY (`member_no`) REFERENCES `member` (`member_no`),
  CONSTRAINT `FK_fboardcoments_freeboard` FOREIGN KEY (`fboard_no`) REFERENCES `freeboard` (`fboard_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COMMENT='자유게시판 댓글';

-- 테이블 데이터 team3.fcomments:~24 rows (대략적) 내보내기
/*!40000 ALTER TABLE `fcomments` DISABLE KEYS */;
INSERT INTO `fcomments` (`f_no`, `member_no`, `fboard_no`, `fcontent`, `fdate`) VALUES
	(11, 2, 77, 'ㅁㄴㅇ', '2021-02-26 18:10:49'),
	(13, 2, 77, 'ㅁㄴㅇ', '2021-02-26 18:11:13'),
	(14, 2, 76, 'asd', '2021-02-27 11:06:14'),
	(16, 2, 78, '수정1611123qweqwe', '2021-02-27 11:14:11'),
	(21, 2, 78, 'qwe', '2021-02-28 20:30:39'),
	(22, 2, 83, 'asd', '2021-03-01 04:58:19'),
	(31, 2, 84, 'asd', '2021-03-02 00:52:53'),
	(32, 2, 84, 'ㅁㄴㅇ', '2021-03-02 01:27:22'),
	(33, 2, 84, 'ㅁㄴㅇ', '2021-03-02 01:27:25'),
	(35, 2, 91, 'qwe', '2021-03-03 13:53:41'),
	(36, 2, 91, 'asd', '2021-03-03 15:46:10'),
	(37, 4, 97, '멋져요!', '2021-03-03 16:00:06'),
	(46, 2, 98, '안되요dddddddddd', '2021-03-03 21:48:01'),
	(51, 2, 99, 'eeee', '2021-03-04 02:11:33'),
	(54, 2, 100, 'ss', '2021-03-04 02:32:24'),
	(56, 2, 102, 'dsdd', '2021-03-04 02:34:31'),
	(58, 2, 102, 'dd', '2021-03-04 02:42:37'),
	(61, 2, 101, 'cc', '2021-03-04 03:03:37'),
	(63, 2, 97, '이뻐요', '2021-03-04 08:48:37'),
	(64, 2, 102, 'as', '2021-03-04 08:57:06'),
	(65, 3, 116, '이쁘네요', '2021-03-05 00:21:39'),
	(66, 7, 116, '귀여워요', '2021-03-05 00:21:44'),
	(70, 74, 78, '오오 ; ', '2021-03-05 14:29:42'),
	(71, 74, 122, 'ㅁㄴㅇㄹ', '2021-03-05 14:30:11');
/*!40000 ALTER TABLE `fcomments` ENABLE KEYS */;

-- 뷰 team3.fcommentsview 구조 내보내기
-- VIEW 종속성 오류를 극복하기 위해 임시 테이블을 생성합니다.
CREATE TABLE `fcommentsview` (
	`f_no` INT(11) NOT NULL,
	`member_no` INT(11) NOT NULL,
	`member_nickname` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`fboard_no` INT(11) NOT NULL,
	`fcontent` VARCHAR(500) NOT NULL COLLATE 'utf8mb4_general_ci',
	`fdate` TIMESTAMP NOT NULL
) ENGINE=MyISAM;

-- 테이블 team3.freeboard 구조 내보내기
CREATE TABLE IF NOT EXISTS `freeboard` (
  `fboard_no` int(11) NOT NULL AUTO_INCREMENT,
  `fboard_title` varchar(100) NOT NULL,
  `fboard_content` varchar(1000) NOT NULL,
  `fboard_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `fboard_views` int(11) NOT NULL DEFAULT 0,
  `member_no` int(11) NOT NULL,
  `fboard_file` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`fboard_no`) USING BTREE,
  KEY `FK_freeboard_member` (`member_no`) USING BTREE,
  CONSTRAINT `FK_freeboard_member` FOREIGN KEY (`member_no`) REFERENCES `member` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8mb4 COMMENT='자유게시판';

-- 테이블 데이터 team3.freeboard:~87 rows (대략적) 내보내기
/*!40000 ALTER TABLE `freeboard` DISABLE KEYS */;
INSERT INTO `freeboard` (`fboard_no`, `fboard_title`, `fboard_content`, `fboard_date`, `fboard_views`, `member_no`, `fboard_file`) VALUES
	(4, '4', '내용입니다.', '2021-02-15 16:08:49', 5, 1, NULL),
	(7, '제목', '내용입니다.', '2021-02-15 16:08:49', 8, 2, NULL),
	(8, '8', '내용입니다.', '2021-02-15 16:08:49', 2, 2, NULL),
	(9, '제목', '내용입니다.', '2021-02-15 16:08:49', 4, 2, NULL),
	(10, '제목', '내용입니다.', '2021-02-15 16:08:49', 1, 2, NULL),
	(11, '제목12', '내용', '2021-02-22 11:55:39', 1, 2, NULL),
	(12, 'ㅁㄴㅇ', 'ㅁㄴㅇ', '2021-02-22 11:57:11', 4, 2, NULL),
	(14, 'qwe', 'qwe', '2021-02-22 16:09:03', 0, 2, '20210222160904.jpg'),
	(15, 'qwe', 'qwe', '2021-02-22 16:10:23', 11, 2, ''),
	(16, 'wer', 'wer', '2021-02-22 16:12:11', 4, 2, '20210222161213.jpg'),
	(17, 'ewq', 'ewwq', '2021-02-22 16:15:37', 0, 2, '20210222161538.jpg'),
	(18, '이게 마지막', 'rwe', '2021-02-22 16:21:57', 18, 2, '20210222162158.jpg'),
	(19, 'qwe', 'qwe', '2021-02-22 16:30:27', 0, 2, ''),
	(20, 'qwe', 'qwe', '2021-02-22 16:31:26', 0, 2, ''),
	(21, 'qwe', 'qwe', '2021-02-22 16:40:22', 0, 2, '20210222164023.jpg'),
	(22, '사진', '사진', '2021-02-22 17:00:14', 0, 2, '20210222170015.jpg'),
	(23, '사진', 'qwe', '2021-02-22 17:18:19', 0, 2, '20210222171819.jpg'),
	(24, 'qwe', 'qwe', '2021-02-22 17:18:26', 0, 2, '20210222171826.jpg'),
	(25, '사진입니다', 'tkwls', '2021-02-22 17:18:55', 0, 2, '20210222171855.jpg'),
	(26, '사진이', '있어요', '2021-02-22 17:27:35', 0, 2, '20210222172736.jpg'),
	(27, 'qwe', 'qwe', '2021-02-23 17:40:32', 0, 2, '20210223174029.png'),
	(28, 'qwe', 'qwe', '2021-02-23 17:40:46', 0, 2, '20210223174043.png'),
	(29, 'qwe', 'qwe', '2021-02-24 07:30:13', 0, 2, '20210224073011.png'),
	(30, 'asd', 'asd', '2021-02-24 07:41:47', 0, 2, ''),
	(31, 'qwe', 'qwe', '2021-02-24 07:48:47', 0, 2, '20210224074845.png'),
	(32, 'qwe', 'qwe', '2021-02-24 07:51:44', 0, 2, '20210224075142.png'),
	(33, '서머노트', '<p>서머노트테스트<br></p>', '2021-02-24 08:04:20', 0, 2, '20210224080418.png'),
	(34, '작성', '<p>작성<br></p>', '2021-02-24 08:38:58', 0, 2, ''),
	(35, '', 'asd', '2021-02-24 08:39:02', 5, 2, ''),
	(36, '', 'qwe', '2021-02-24 08:39:14', 0, 2, ''),
	(37, '제목', '<p>내용<br></p>', '2021-02-24 08:40:35', 0, 2, ''),
	(38, '제목1', '<p>내용1<br></p>', '2021-02-24 08:44:20', 1, 2, ''),
	(40, 'qwe', '<p>qwe<br></p>', '2021-02-24 08:56:01', 0, 2, ''),
	(43, 'aa', '<p>aa<br></p>', '2021-02-24 08:58:53', 0, 2, ''),
	(44, 'aa', '<p>aa<br></p>', '2021-02-24 08:59:44', 0, 2, ''),
	(45, 'ㅁㅁ', '<p>ㅁㅁ</p>', '2021-02-24 09:00:32', 0, 2, ''),
	(46, 'ㅁㅁ', '<p>ㅁㅁ</p>', '2021-02-24 09:00:42', 0, 2, ''),
	(47, 'ㅂㅂ', '<p>ㅂㅂㅂ</p>', '2021-02-24 09:00:47', 0, 2, ''),
	(48, 'qwe', '<p>qwe<br></p>', '2021-02-24 13:30:35', 0, 2, ''),
	(49, 'qwe', '<p>qwe<br></p>', '2021-02-25 17:12:50', 1, 2, ''),
	(50, '정렬', '<p>정렬<br></p>', '2021-02-26 16:50:31', 1, 2, ''),
	(51, 'zxc', '<p>zxc<br></p>', '2021-02-26 16:58:32', 2, 2, ''),
	(52, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:01:15', 1, 2, ''),
	(53, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:03:51', 1, 2, ''),
	(54, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:04:24', 1, 2, ''),
	(55, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:05:00', 9, 2, ''),
	(56, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:09:40', 1, 2, ''),
	(57, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:09:42', 0, 2, ''),
	(58, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:09:49', 1, 2, ''),
	(59, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:10:49', 13, 2, ''),
	(63, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:14:55', 0, 2, ''),
	(64, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:15:34', 8, 2, ''),
	(65, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:18:36', 5, 2, NULL),
	(66, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:21:05', 0, 2, NULL),
	(67, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:22:36', 1, 2, ''),
	(68, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:24:09', 1, 2, ''),
	(69, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:24:43', 1, 2, ''),
	(70, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:27:32', 1, 2, ''),
	(71, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:27:55', 2, 2, ''),
	(72, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:28:41', 0, 2, ''),
	(73, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:30:30', 2, 2, NULL),
	(74, 'qwe', '<p>qwe<br></p>', '2021-02-26 17:30:46', 3, 2, '20210226173046.png'),
	(76, '쓰기', '<p>쓰기<br></p>', '2021-02-26 18:08:13', 6, 2, NULL),
	(77, '수정', '<p>수정<br></p>', '2021-02-26 18:08:33', 25, 2, '20210226180833.png'),
	(78, '자유게시판', '<p>이에요s</p><p><br></p><p><br></p>', '2021-02-27 11:14:08', 217, 2, NULL),
	(83, '안녕하세요', '<p>ㅁㄴㅇ<br></p>', '2021-02-28 21:47:37', 37, 2, NULL),
	(84, '반려동물', '<p>asdasadd</p>', '2021-03-01 18:43:58', 199, 2, NULL),
	(88, '글', '<p>ㅁㄴㅇ<br></p>', '2021-03-02 15:06:55', 13, 2, NULL),
	(89, '고양이입니다', '<p>qwe<br></p>', '2021-03-02 15:09:13', 23, 2, NULL),
	(90, '멋진반려동물', '<p>df<br></p>', '2021-03-02 15:12:52', 42, 2, NULL),
	(91, '강아지', '<p>qweas<br></p>', '2021-03-03 13:53:35', 40, 2, NULL),
	(92, 'as', '<p>as<br></p>', '2021-03-03 15:47:08', 7, 2, '20210303154653.jpg'),
	(93, '귀여운 강아지', '<p>강아지는 귀여워</p>', '2021-03-03 15:56:10', 2, 2, NULL),
	(94, '아름다운 강아지', '<p>강아지는 아름다워</p>', '2021-03-03 15:56:20', 2, 3, NULL),
	(95, '멋진강아지', '<p>강이지는 멋쟁이</p>', '2021-03-03 15:56:32', 4, 2, NULL),
	(97, '우리 강아지 이쁘지 않나요?', '<p>우리집강아지</p>', '2021-03-03 15:57:26', 48, 2, '20210303155711.jpg'),
	(98, '건강한사료', '<p>사람이먹어도되요.</p>', '2021-03-03 15:58:08', 15, 67, NULL),
	(99, '고양이는 심심해요', '<p>고양이</p>', '2021-03-03 15:58:26', 8, 2, NULL),
	(100, '안녕하세요 ~ 고양이 키우고 있어요', '키우는 고양이', '2021-03-03 15:58:44', 11, 3, NULL),
	(101, '반갑습니다.', '<p>반가워요ㄹㄹ</p>', '2021-03-03 15:58:55', 31, 2, NULL),
	(102, '고양이가 건강해요.', '<p>건강한고양이</p>', '2021-03-03 15:59:09', 94, 4, NULL),
	(116, '강아지 이뻐요!', '<p>이뻐요 강아지</p>', '2021-03-05 00:21:32', 6, 2, '20210305002130.jpg'),
	(118, 'dd', '<p>dd</p>', '2021-03-05 00:42:38', 1, 2, NULL),
	(119, 'dd', '<p>dd</p>', '2021-03-05 01:10:48', 2, 2, NULL),
	(121, '22', '<p>2<br></p>', '2021-03-05 01:27:17', 2, 75, NULL),
	(122, 'dd', '<p>dd</p>', '2021-03-05 01:44:52', 4, 1, NULL),
	(123, '난 개가 싫어', '<p>제곧내</p>', '2021-03-05 10:50:27', 8, 74, NULL);
/*!40000 ALTER TABLE `freeboard` ENABLE KEYS */;

-- 뷰 team3.freeboardview 구조 내보내기
-- VIEW 종속성 오류를 극복하기 위해 임시 테이블을 생성합니다.
CREATE TABLE `freeboardview` (
	`count` BIGINT(21) NULL,
	`fboard_no` INT(11) NOT NULL,
	`member_nickname` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`fboard_title` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`fboard_content` VARCHAR(1000) NOT NULL COLLATE 'utf8mb4_general_ci',
	`fboard_date` TIMESTAMP NOT NULL,
	`fboard_views` INT(11) NOT NULL,
	`fboard_file` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`member_no` INT(5) NOT NULL,
	`comments` BIGINT(21) NULL,
	`rowno` BIGINT(21) NOT NULL
) ENGINE=MyISAM;

-- 테이블 team3.hcomments 구조 내보내기
CREATE TABLE IF NOT EXISTS `hcomments` (
  `h_no` int(11) NOT NULL AUTO_INCREMENT,
  `member_no` int(11) NOT NULL,
  `hboard_no` int(11) NOT NULL,
  `hcontent` varchar(500) NOT NULL,
  `hdate` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`h_no`) USING BTREE,
  KEY `FK_hcomments_humorboard` (`hboard_no`),
  KEY `FK_hcomments_member` (`member_no`),
  CONSTRAINT `FK_hcomments_humorboard` FOREIGN KEY (`hboard_no`) REFERENCES `humorboard` (`hboard_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_hcomments_member` FOREIGN KEY (`member_no`) REFERENCES `member` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COMMENT='유머게시판 댓글';

-- 테이블 데이터 team3.hcomments:~6 rows (대략적) 내보내기
/*!40000 ALTER TABLE `hcomments` DISABLE KEYS */;
INSERT INTO `hcomments` (`h_no`, `member_no`, `hboard_no`, `hcontent`, `hdate`) VALUES
	(1, 2, 1, '유머댓글', '2021-02-15 14:56:50'),
	(2, 2, 1, 'asd', '2021-02-28 08:21:10'),
	(13, 3, 16, '?', '2021-03-03 14:48:52'),
	(14, 4, 16, '??', '2021-03-03 14:48:55'),
	(20, 2, 14, 'dddd', '2021-03-04 01:26:43'),
	(35, 87, 27, 'ㅁㄴㅇㄹㅇㄴㅁㄹ', '2021-03-05 15:54:58');
/*!40000 ALTER TABLE `hcomments` ENABLE KEYS */;

-- 뷰 team3.hcommentsview 구조 내보내기
-- VIEW 종속성 오류를 극복하기 위해 임시 테이블을 생성합니다.
CREATE TABLE `hcommentsview` (
	`h_no` INT(11) NOT NULL,
	`member_no` INT(11) NOT NULL,
	`member_nickname` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`hboard_no` INT(11) NOT NULL,
	`hcontent` VARCHAR(500) NOT NULL COLLATE 'utf8mb4_general_ci',
	`hdate` TIMESTAMP NOT NULL
) ENGINE=MyISAM;

-- 테이블 team3.humorboard 구조 내보내기
CREATE TABLE IF NOT EXISTS `humorboard` (
  `hboard_no` int(11) NOT NULL AUTO_INCREMENT,
  `hboard_title` varchar(100) NOT NULL,
  `hboard_content` varchar(1000) NOT NULL,
  `hboard_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `hboard_views` int(11) NOT NULL DEFAULT 0,
  `member_no` int(11) NOT NULL,
  `hboard_file` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`hboard_no`) USING BTREE,
  KEY `FK_humorboard_member` (`member_no`) USING BTREE,
  CONSTRAINT `FK_humorboard_member` FOREIGN KEY (`member_no`) REFERENCES `member` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COMMENT='유머게시판';

-- 테이블 데이터 team3.humorboard:~7 rows (대략적) 내보내기
/*!40000 ALTER TABLE `humorboard` DISABLE KEYS */;
INSERT INTO `humorboard` (`hboard_no`, `hboard_title`, `hboard_content`, `hboard_date`, `hboard_views`, `member_no`, `hboard_file`) VALUES
	(1, '유머제목', '유머내용', '2021-02-15 11:38:16', 27, 2, NULL),
	(13, '유머', '<p>유머<br></p>', '2021-03-02 15:13:20', 11, 2, NULL),
	(14, '동해물과백두산이', '<p>aa<br></p>', '2021-03-02 16:19:29', 24, 2, NULL),
	(16, '바나나를 먹으면', '<p>원숭이</p>', '2021-03-02 16:19:40', 94, 2, NULL),
	(23, '난 고양이도 싫어', '<p>제 곧내ㅁㄴㅇㄻㄴㅇㄹ</p>', '2021-03-05 10:51:10', 7, 74, NULL),
	(25, 'qqqqqqq', '<p>qweqaz</p>', '2021-03-05 15:37:48', 118, 79, NULL),
	(27, 'ㅁㅇㄴㄻㄴㄹ', '<p>ㅇㄴㅁㄹㄴ</p>', '2021-03-05 15:54:52', 8, 87, NULL);
/*!40000 ALTER TABLE `humorboard` ENABLE KEYS */;

-- 뷰 team3.humorboardview 구조 내보내기
-- VIEW 종속성 오류를 극복하기 위해 임시 테이블을 생성합니다.
CREATE TABLE `humorboardview` (
	`count` BIGINT(21) NULL,
	`hboard_no` INT(11) NOT NULL,
	`member_nickname` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`hboard_title` VARCHAR(100) NOT NULL COLLATE 'utf8mb4_general_ci',
	`hboard_content` VARCHAR(1000) NOT NULL COLLATE 'utf8mb4_general_ci',
	`hboard_date` TIMESTAMP NOT NULL,
	`hboard_views` INT(11) NOT NULL,
	`hboard_file` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`member_no` INT(5) NOT NULL,
	`comments` BIGINT(21) NULL,
	`rowno` BIGINT(21) NOT NULL
) ENGINE=MyISAM;

-- 테이블 team3.marketboard 구조 내보내기
CREATE TABLE IF NOT EXISTS `marketboard` (
  `m_no` int(11) NOT NULL AUTO_INCREMENT,
  `mboard_title` varchar(50) NOT NULL DEFAULT '',
  `mboard_content` mediumtext NOT NULL DEFAULT '',
  `mboard_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `mboard_views` int(11) NOT NULL DEFAULT 0,
  `member_no` int(11) NOT NULL DEFAULT 0,
  `mboard_file` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`m_no`),
  KEY `member_no` (`member_no`),
  CONSTRAINT `FK_marketboard_member` FOREIGN KEY (`member_no`) REFERENCES `member` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4;

-- 테이블 데이터 team3.marketboard:~72 rows (대략적) 내보내기
/*!40000 ALTER TABLE `marketboard` DISABLE KEYS */;
INSERT INTO `marketboard` (`m_no`, `mboard_title`, `mboard_content`, `mboard_date`, `mboard_views`, `member_no`, `mboard_file`) VALUES
	(18, '팔아요', '중형견 멈무이 입마개', '2021-03-05 01:22:46', 1197, 2, NULL),
	(19, '네셔널지오그래픽', '기니피그 탄생의순간', '2021-03-05 15:35:56', 489, 4, NULL),
	(24, 'd', 'aaaaaaaaaa', '2021-03-03 22:47:27', 288, 1, NULL),
	(29, 'title', 'content\r\n', '2021-03-03 22:44:30', 31, 1, NULL),
	(31, 'ㅇ', 'ㅇ', '2021-03-03 22:14:42', 10, 1, NULL),
	(32, '대형견켄넬', '켄넬 10만원입니다', '2021-03-05 15:35:26', 51, 1, NULL),
	(44, 'ㅇㄹ', 'ㅇㄹ', '2021-03-03 13:57:00', 7, 1, NULL),
	(45, 'df', 'f', '2021-03-02 20:31:09', 1, 1, NULL),
	(46, 'df', 'df', '2021-03-03 22:44:00', 2, 1, NULL),
	(47, '하나둘', '..', '2021-03-02 20:31:35', 1, 1, NULL),
	(48, 'gn', 'gn', '2021-03-04 21:21:09', 2, 1, NULL),
	(49, 'gn', 'gn', '2021-03-04 21:20:24', 2, 1, NULL),
	(50, 'asdf', 'asdf', '2021-03-02 20:48:04', 1, 2, NULL),
	(51, '테스트 1213', '테스트 121313ㄹㄹㄹㄹㄹㄹ', '2021-03-04 01:17:41', 2, 2, NULL),
	(52, '아아', '아아', '2021-03-05 15:39:14', 1, 2, NULL),
	(53, 'df', 'dfdddd', '2021-03-05 15:35:52', 30, 7, NULL),
	(54, 'asdf', 'asdf', '2021-03-05 15:39:18', 31, 7, NULL),
	(56, '테스트ㅇㅇ', '<p>테스트ㅇㅇ<br></p>', '2021-03-05 11:37:25', 67, 2, NULL),
	(57, '1234', '<p>12341234<br></p>', '2021-03-05 15:34:58', 56, 2, NULL),
	(58, 'dfdf', '<p>df13dsfdf</p>', '2021-03-05 01:11:04', 36, 2, NULL),
	(63, 'dd', '<p>dd</p>', '2021-03-05 15:55:52', 7, 1, NULL),
	(64, 'ddd', '<p>ddd</p>', '2021-03-05 10:51:20', 13, 1, NULL),
	(65, '거북이는 좋아 ', '<p>거북이 삼&nbsp;</p>', '2021-03-05 15:40:09', 41, 74, NULL),
	(67, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:03', 1, 87, NULL),
	(68, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:09', 0, 87, NULL),
	(69, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:36', 53, 87, NULL),
	(70, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:41', 0, 87, NULL),
	(71, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:42', 0, 87, NULL),
	(72, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:42', 0, 87, NULL),
	(73, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:43', 0, 87, NULL),
	(74, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:43', 0, 87, NULL),
	(75, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:43', 0, 87, NULL),
	(76, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:44', 0, 87, NULL),
	(77, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:44', 0, 87, NULL),
	(78, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:44', 0, 87, NULL),
	(79, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:45', 0, 87, NULL),
	(80, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:45', 0, 87, NULL),
	(81, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:45', 0, 87, NULL),
	(82, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:45', 0, 87, NULL),
	(83, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:46', 0, 87, NULL),
	(84, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:46', 0, 87, NULL),
	(85, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:46', 0, 87, NULL),
	(86, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:47', 0, 87, NULL),
	(87, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:47', 0, 87, NULL),
	(88, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:47', 0, 87, NULL),
	(89, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:47', 0, 87, NULL),
	(90, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:48', 0, 87, NULL),
	(91, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:48', 0, 87, NULL),
	(92, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:48', 0, 87, NULL),
	(93, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:49', 0, 87, NULL),
	(94, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:49', 0, 87, NULL),
	(95, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:50', 0, 87, NULL),
	(96, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:56', 0, 87, NULL),
	(97, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:56', 0, 87, NULL),
	(98, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:57', 0, 87, NULL),
	(99, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:57', 0, 87, NULL),
	(100, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:57', 0, 87, NULL),
	(101, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:57', 0, 87, NULL),
	(102, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:58', 0, 87, NULL),
	(103, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:58', 0, 87, NULL),
	(104, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:58', 0, 87, NULL),
	(105, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:59', 0, 87, NULL),
	(106, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:56:59', 0, 87, NULL),
	(107, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:57:00', 0, 87, NULL),
	(108, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:57:00', 0, 87, NULL),
	(109, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:57:00', 0, 87, NULL),
	(110, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:57:01', 0, 87, NULL),
	(111, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:57:01', 0, 87, NULL),
	(112, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:57:01', 0, 87, NULL),
	(113, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:57:02', 0, 87, NULL),
	(114, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:57:03', 0, 87, NULL),
	(115, '<!--', '<p>&lt;!--<br></p>', '2021-03-05 15:57:03', 0, 87, NULL);
/*!40000 ALTER TABLE `marketboard` ENABLE KEYS */;

-- 뷰 team3.marketboardview 구조 내보내기
-- VIEW 종속성 오류를 극복하기 위해 임시 테이블을 생성합니다.
CREATE TABLE `marketboardview` (
	`count` BIGINT(21) NULL,
	`m_no` INT(11) NOT NULL,
	`member_nickname` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`mboard_title` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`mboard_content` MEDIUMTEXT NOT NULL COLLATE 'utf8mb4_general_ci',
	`mboard_date` TIMESTAMP NOT NULL,
	`mboard_views` INT(11) NOT NULL,
	`mboard_file` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`member_no` INT(5) NOT NULL,
	`comments` BIGINT(21) NULL,
	`rowno` BIGINT(21) NOT NULL
) ENGINE=MyISAM;

-- 테이블 team3.mcomments 구조 내보내기
CREATE TABLE IF NOT EXISTS `mcomments` (
  `mc_no` int(11) NOT NULL AUTO_INCREMENT,
  `member_no` int(11) NOT NULL,
  `m_no` int(11) NOT NULL,
  `mcontent` varchar(500) NOT NULL,
  `mdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`mc_no`) USING BTREE,
  KEY `FK_mcomments_marketboard` (`m_no`) USING BTREE,
  KEY `FK_mcomments_member` (`member_no`) USING BTREE,
  CONSTRAINT `FK_marketboardcomments_marketboard` FOREIGN KEY (`m_no`) REFERENCES `marketboard` (`m_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_marketboardcomments_member` FOREIGN KEY (`member_no`) REFERENCES `member` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4;

-- 테이블 데이터 team3.mcomments:~29 rows (대략적) 내보내기
/*!40000 ALTER TABLE `mcomments` DISABLE KEYS */;
INSERT INTO `mcomments` (`mc_no`, `member_no`, `m_no`, `mcontent`, `mdate`) VALUES
	(11, 1, 31, 'dd', '2021-03-03 22:14:42'),
	(16, 1, 19, 'ddㅇㅇ', '2021-03-02 15:20:56'),
	(17, 1, 19, 'ddd', '2021-02-23 11:47:58'),
	(24, 1, 19, 'd', '2021-02-24 09:23:04'),
	(25, 1, 19, 'dfdf\r\n', '2021-02-24 11:50:44'),
	(27, 1, 19, 'wewewe3', '2021-03-04 01:31:49'),
	(29, 1, 24, 'aaㅇㅇ\r\n', '2021-03-02 15:19:18'),
	(32, 1, 18, 'qwe', '2021-02-25 15:57:08'),
	(35, 1, 18, 'dd', '2021-02-26 13:49:29'),
	(57, 1, 18, '44', '2021-03-02 13:59:47'),
	(60, 1, 32, 'df', '2021-03-02 14:02:09'),
	(61, 1, 19, 'ad', '2021-03-02 14:04:54'),
	(62, 1, 44, 'ㅇㅇㅇㅇㅇㅇ', '2021-03-03 13:53:14'),
	(63, 1, 19, 'ㅇㅇ', '2021-03-03 21:49:25'),
	(64, 1, 19, 'ㄹㅇ', '2021-03-03 21:50:45'),
	(65, 1, 19, 'asd', '2021-03-03 21:52:54'),
	(66, 1, 46, 'dd', '2021-03-03 22:44:00'),
	(67, 1, 29, 'd', '2021-03-03 22:44:30'),
	(70, 2, 53, 'df', '2021-03-04 00:43:31'),
	(71, 2, 54, 'gggee', '2021-03-04 02:30:43'),
	(73, 2, 56, 'dd', '2021-03-04 01:12:24'),
	(74, 2, 57, '12341234d', '2021-03-04 02:51:30'),
	(75, 2, 56, 'dd', '2021-03-04 01:35:00'),
	(76, 2, 57, '2424', '2021-03-04 01:48:53'),
	(81, 1, 54, 'ㅎㅇ', '2021-03-04 12:34:16'),
	(83, 1, 57, 'ㅇㅇㅇㅇ', '2021-03-04 12:35:20'),
	(84, 1, 58, 'ㅇㅇㅇ', '2021-03-04 12:35:49'),
	(85, 7, 58, 'sdfdd', '2021-03-04 12:37:11'),
	(89, 79, 65, 'qqqqqqqqqqq', '2021-03-05 15:34:18');
/*!40000 ALTER TABLE `mcomments` ENABLE KEYS */;

-- 뷰 team3.mcommentsview 구조 내보내기
-- VIEW 종속성 오류를 극복하기 위해 임시 테이블을 생성합니다.
CREATE TABLE `mcommentsview` (
	`mc_no` INT(11) NOT NULL,
	`member_no` INT(11) NOT NULL,
	`member_nickname` VARCHAR(50) NULL COLLATE 'utf8mb4_general_ci',
	`m_no` INT(11) NOT NULL,
	`mcontent` VARCHAR(500) NOT NULL COLLATE 'utf8mb4_general_ci',
	`mdate` TIMESTAMP NOT NULL
) ENGINE=MyISAM;

-- 테이블 team3.member 구조 내보내기
CREATE TABLE IF NOT EXISTS `member` (
  `member_no` int(5) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(50) NOT NULL,
  `member_pw` varchar(50) NOT NULL,
  `member_nickname` varchar(50) NOT NULL,
  `member_email` varchar(50) NOT NULL,
  `member_grade` int(1) NOT NULL DEFAULT 5,
  `member_ph` varchar(50) NOT NULL,
  `member_birth` varchar(50) NOT NULL,
  `member_name` varchar(50) NOT NULL,
  PRIMARY KEY (`member_no`),
  UNIQUE KEY `member_id` (`member_id`),
  UNIQUE KEY `member_ph` (`member_ph`),
  UNIQUE KEY `member_email` (`member_email`),
  UNIQUE KEY `member_nickname` (`member_nickname`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4;

-- 테이블 데이터 team3.member:~31 rows (대략적) 내보내기
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` (`member_no`, `member_id`, `member_pw`, `member_nickname`, `member_email`, `member_grade`, `member_ph`, `member_birth`, `member_name`) VALUES
	(1, '운영자', '2222', '운영자', 'an12dy34@gmail.com', 9, '01086969615', '1994-02-22', '이상현'),
	(2, 'qwert', '1234', '테스터', 'test01@naver.com', 5, '01012345678', '2000-01-03>', '회원1'),
	(3, 'zzzzzz', '789789', '잠만보', 'su22222@hanmail.net', 5, '01078945612', '1990-01-01', '회원2'),
	(4, 'BBBBBB', '456456', '비이잉', 'SASAQE@nate.com', 5, '01099998899', '1991-02-02', '가'),
	(7, 'asdf', 'asdf', 'zzzzzzz', 'adfsfasdf@naver.com', 5, '01044446666', '2554854>', '나'),
	(8, 'asdfg', '12345', '테스터2', 'asd@naver.com', 5, '01011111111', '2000-10-10', '이름'),
	(43, 'wwwwww', '333333', '탸탸탸', 'sdadasd@kakao.com', 1, '01089781231', '19990909', 'ZZZZ'),
	(51, 'ddddddd', '456456', '야너두', 'safdsf@kakao.com', 5, '01011114444', '124', '야나두'),
	(59, 'nnnnnnn', '7777777', '사용중', 'sdrersdf@nate.com', 5, '01045443232', '456456', '기달달'),
	(65, 'rrrrrr', '222222', 'wwwww', 'dsfdsfxzc@hanmail.net', 5, '01054451223', '34132415', '하하핳'),
	(66, 'uuuuuu', '1234567', '이야얍', 'asfdasdfas@naver.com', 5, '01055221636', '2020-03-11', '길동홍'),
	(67, 'ssssss', '888888', '릴리리야', 'tytyu@kakao.com', 5, '01012224545', '56456433', '오호홍'),
	(68, 'cccccc', '888888', '꾸잉', 'hjghjgh@nate.com', 5, '01077771636', '2021-03-26', '뭡니까'),
	(69, 'iiiiii', '444444', '내가왔다', 'wjkuszz11@naver.com', 5, '01099996666', '2021-03-03', '알았다고옹'),
	(70, 'pppppp', '888888', '왔다냥', 'ffghfg@hanmail.net', 5, '01041236666', '1994-10-11', '끼에엨'),
	(71, 'kkkkkk', '0000000', '밀갱이', 'hjghjgh@naver.com', 9, '01053321636', '2020-12-03', '정민경'),
	(72, 'lee', '1234', 'lee', 'a@gmail.com', 5, '0101010101', '123124', 'a'),
	(73, 'oooooo', '1111111', '오잉크', '757467@kakao.com', 5, '01054648856', '2021-04-01', '김도깡'),
	(74, '박준하', '1234', '박준하', 'ㅁㄴㅇㄹ@naver.com', 1, '01020306807', '940322', '박준하'),
	(75, 'qwer', 'qwer', 'qw', 'qwer@naver.com', 1, '01012342353', '121111', 'qwer'),
	(76, 'qwgg', 'qwgg', 'qwgg', 'qwgg@naver.com', 1, '01024241244', '121111', 'qwgg'),
	(78, 'nyanya', '1234', '냐냐', 'nyanya@naver.com', 5, '01012341234', '2021-03-04', '냐냐'),
	(79, 'admin', 'qweqwe', 'admin', '2@qw', 5, '010qqqqqqqw', '1895-01-06', 'a'),
	(80, 'or \'1=1\'', 'or \'1=1\' or', '\'1=1\'', 'or \'1=1\' or@or \'1=1\' or', 5, '010/*/*', '2025-11-08', '\'1=1\''),
	(81, 'sss', 'sss', 'sss', 'sss@sss', 5, '010ssssss', '2021-03-11', 'ssss'),
	(82, 'ccccc', 'ccccc', 'ccccc', 'ccccc@ccccc', 5, '010cccccccc', '2021-03-09', 'ccccc'),
	(83, 'qqqq', 'qqqq', 'qqqq', 'qqqq@qqqq', 5, '010qqqqqqqq', '2021-03-04', 'qqqq'),
	(84, '31', '31', '31312', '31@31', 5, '0103131', '2021-03-04', '31311'),
	(85, 'or 1=1', 'or 1=1', '죄송', 'or 1=1@or 1=1', 5, '0101=1/*', '2021-04-09', '죄송'),
	(86, 'aaaa', 'aaaa', 'ㄹㅇㄹㅇ', 'aaaa@naver.com', 5, '01001010101', '2021-03-04', '이이름'),
	(87, '<div', '<div', '<div', '<div@<div', 5, '010<div<div', '2021-03-17', '<div');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;

-- 뷰 team3.memberview 구조 내보내기
-- VIEW 종속성 오류를 극복하기 위해 임시 테이블을 생성합니다.
CREATE TABLE `memberview` (
	`member_name` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`member_nickname` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`member_no` INT(5) NOT NULL,
	`member_id` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`member_pw` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`member_birth` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`member_grade` INT(1) NOT NULL
) ENGINE=MyISAM;

-- 테이블 team3.noticeboard 구조 내보내기
CREATE TABLE IF NOT EXISTS `noticeboard` (
  `n_no` int(11) NOT NULL AUTO_INCREMENT,
  `n_title` varchar(50) NOT NULL DEFAULT '0',
  `n_content` text NOT NULL DEFAULT '0',
  `n_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `n_views` int(11) NOT NULL DEFAULT 0,
  `member_no` int(11) NOT NULL,
  `n_file` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`n_no`),
  KEY `FK_noticeboard_member` (`member_no`),
  CONSTRAINT `FK_noticeboard_member` FOREIGN KEY (`member_no`) REFERENCES `member` (`member_no`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COMMENT='번호 / 제목 / 내용 / 작성일 / 조회수 / 개인번호';

-- 테이블 데이터 team3.noticeboard:~8 rows (대략적) 내보내기
/*!40000 ALTER TABLE `noticeboard` DISABLE KEYS */;
INSERT INTO `noticeboard` (`n_no`, `n_title`, `n_content`, `n_date`, `n_views`, `member_no`, `n_file`) VALUES
	(56, '아', '메리카노', '2021-03-05 15:43:43', 2, 1, NULL),
	(57, '호', '롤룰루', '2021-03-05 15:43:37', 3, 1, NULL),
	(58, '홍', '콩반점', '2021-03-05 15:43:30', 4, 1, NULL),
	(59, '도', '비이즈프리', '2021-03-05 15:43:21', 3, 1, NULL),
	(60, '궁', '금하면 오백원ㅇ', '2021-03-05 15:43:16', 8, 1, NULL),
	(62, '늦었', '<p>다고 느껴지면 답이 없다</p>', '2021-03-05 15:43:06', 12, 1, '20210304211414.jpg'),
	(63, '11', '<p>11</p>', '2021-03-05 15:40:17', 14, 1, NULL),
	(64, 'dd', '<p>dd</p>', '2021-03-05 15:40:13', 9, 1, NULL);
/*!40000 ALTER TABLE `noticeboard` ENABLE KEYS */;

-- 뷰 team3.noticeview 구조 내보내기
-- VIEW 종속성 오류를 극복하기 위해 임시 테이블을 생성합니다.
CREATE TABLE `noticeview` (
	`count` BIGINT(21) NULL,
	`n_no` INT(11) NOT NULL,
	`member_nickname` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`n_title` VARCHAR(50) NOT NULL COLLATE 'utf8mb4_general_ci',
	`n_content` TEXT NOT NULL COLLATE 'utf8mb4_general_ci',
	`n_date` TIMESTAMP NOT NULL,
	`n_views` INT(11) NOT NULL,
	`n_file` VARCHAR(100) NULL COLLATE 'utf8mb4_general_ci',
	`member_no` INT(5) NOT NULL,
	`rowno` BIGINT(21) NOT NULL
) ENGINE=MyISAM;

-- 뷰 team3.fcommentsview 구조 내보내기
-- 임시 테이블을 제거하고 최종 VIEW 구조를 생성
DROP TABLE IF EXISTS `fcommentsview`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `fcommentsview` AS select `fcomments`.`f_no` AS `f_no`,`fcomments`.`member_no` AS `member_no`,(select `member`.`member_nickname` from `member` where `member`.`member_no` = `fcomments`.`member_no`) AS `member_nickname`,`fcomments`.`fboard_no` AS `fboard_no`,`fcomments`.`fcontent` AS `fcontent`,`fcomments`.`fdate` AS `fdate` from `fcomments` order by `fcomments`.`f_no`;

-- 뷰 team3.freeboardview 구조 내보내기
-- 임시 테이블을 제거하고 최종 VIEW 구조를 생성
DROP TABLE IF EXISTS `freeboardview`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `freeboardview` AS select (select count(0) from `freeboard`) AS `count`,`freeboard`.`fboard_no` AS `fboard_no`,`member`.`member_nickname` AS `member_nickname`,`freeboard`.`fboard_title` AS `fboard_title`,`freeboard`.`fboard_content` AS `fboard_content`,`freeboard`.`fboard_date` AS `fboard_date`,`freeboard`.`fboard_views` AS `fboard_views`,`freeboard`.`fboard_file` AS `fboard_file`,`member`.`member_no` AS `member_no`,(select count(0) from `fcomments` `c` where `c`.`fboard_no` = `freeboard`.`fboard_no`) AS `comments`,row_number() over () AS `rowno` from (`freeboard` join `member` on(`freeboard`.`member_no` = `member`.`member_no`)) order by `freeboard`.`fboard_no` desc;

-- 뷰 team3.hcommentsview 구조 내보내기
-- 임시 테이블을 제거하고 최종 VIEW 구조를 생성
DROP TABLE IF EXISTS `hcommentsview`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `hcommentsview` AS select `hcomments`.`h_no` AS `h_no`,`hcomments`.`member_no` AS `member_no`,(select `member`.`member_nickname` from `member` where `member`.`member_no` = `hcomments`.`member_no`) AS `member_nickname`,`hcomments`.`hboard_no` AS `hboard_no`,`hcomments`.`hcontent` AS `hcontent`,`hcomments`.`hdate` AS `hdate` from `hcomments` order by `hcomments`.`h_no`;

-- 뷰 team3.humorboardview 구조 내보내기
-- 임시 테이블을 제거하고 최종 VIEW 구조를 생성
DROP TABLE IF EXISTS `humorboardview`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `humorboardview` AS select (select count(0) from `humorboard`) AS `count`,`humorboard`.`hboard_no` AS `hboard_no`,`member`.`member_nickname` AS `member_nickname`,`humorboard`.`hboard_title` AS `hboard_title`,`humorboard`.`hboard_content` AS `hboard_content`,`humorboard`.`hboard_date` AS `hboard_date`,`humorboard`.`hboard_views` AS `hboard_views`,`humorboard`.`hboard_file` AS `hboard_file`,`member`.`member_no` AS `member_no`,(select count(0) from `hcomments` `c` where `c`.`hboard_no` = `humorboard`.`hboard_no`) AS `comments`,row_number() over () AS `rowno` from (`humorboard` join `member` on(`humorboard`.`member_no` = `member`.`member_no`)) order by `humorboard`.`hboard_no` desc;

-- 뷰 team3.marketboardview 구조 내보내기
-- 임시 테이블을 제거하고 최종 VIEW 구조를 생성
DROP TABLE IF EXISTS `marketboardview`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `marketboardview` AS select (select count(0) from `marketboard`) AS `count`,`marketboard`.`m_no` AS `m_no`,`member`.`member_nickname` AS `member_nickname`,`marketboard`.`mboard_title` AS `mboard_title`,`marketboard`.`mboard_content` AS `mboard_content`,`marketboard`.`mboard_date` AS `mboard_date`,`marketboard`.`mboard_views` AS `mboard_views`,`marketboard`.`mboard_file` AS `mboard_file`,`member`.`member_no` AS `member_no`,(select count(0) from `mcomments` `c` where `c`.`m_no` = `marketboard`.`m_no`) AS `comments`,row_number() over () AS `rowno` from (`marketboard` join `member` on(`marketboard`.`member_no` = `member`.`member_no`)) order by `marketboard`.`m_no` desc;

-- 뷰 team3.mcommentsview 구조 내보내기
-- 임시 테이블을 제거하고 최종 VIEW 구조를 생성
DROP TABLE IF EXISTS `mcommentsview`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `mcommentsview` AS select `mcomments`.`mc_no` AS `mc_no`,`mcomments`.`member_no` AS `member_no`,(select `member`.`member_nickname` from `member` where `member`.`member_no` = `mcomments`.`member_no`) AS `member_nickname`,`mcomments`.`m_no` AS `m_no`,`mcomments`.`mcontent` AS `mcontent`,`mcomments`.`mdate` AS `mdate` from `mcomments` order by `mcomments`.`mc_no` WITH LOCAL CHECK OPTION;

-- 뷰 team3.memberview 구조 내보내기
-- 임시 테이블을 제거하고 최종 VIEW 구조를 생성
DROP TABLE IF EXISTS `memberview`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `memberview` AS select `member`.`member_name` AS `member_name`,`member`.`member_nickname` AS `member_nickname`,`member`.`member_no` AS `member_no`,`member`.`member_id` AS `member_id`,`member`.`member_pw` AS `member_pw`,`member`.`member_birth` AS `member_birth`,`member`.`member_grade` AS `member_grade` from `member`;

-- 뷰 team3.noticeview 구조 내보내기
-- 임시 테이블을 제거하고 최종 VIEW 구조를 생성
DROP TABLE IF EXISTS `noticeview`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `noticeview` AS select (select count(0) from `noticeboard`) AS `count`,`noticeboard`.`n_no` AS `n_no`,`member`.`member_nickname` AS `member_nickname`,`noticeboard`.`n_title` AS `n_title`,`noticeboard`.`n_content` AS `n_content`,`noticeboard`.`n_date` AS `n_date`,`noticeboard`.`n_views` AS `n_views`,`noticeboard`.`n_file` AS `n_file`,`member`.`member_no` AS `member_no`,row_number() over () AS `rowno` from (`noticeboard` join `member` on(`noticeboard`.`member_no` = `member`.`member_no`)) order by `noticeboard`.`n_no` desc;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
