package com.team3.login;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




@WebServlet("/idfind")
public class idFind extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public idFind() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		if (request.getParameter("name") != null && request.getParameter("email") != null) {
			String name = request.getParameter("name");
			String email = request.getParameter("email");
//			System.out.println("정상입니다.");
			JoinDAO dao = new JoinDAO();
			ArrayList<String> result = dao.idFind(name, email);
			request.setAttribute("dto", result);
			RequestDispatcher rd = request.getRequestDispatcher("./idfind.jsp");
			rd.forward(request, response);

		} else {
			System.out.println("회원가입 먼저 해주세요.");
		}

//		LoginDTO dto = new LoginDTO();
//		dto.setMember_name(name);
//		dto.setMember_email(email);
		/*
		 * if (dto.getMember_name() != null && dto.getMember_email() != null) {
		 * 
		 * HttpSession session = request.getSession();
		 * session.setAttribute("member_name", dto.getMember_name());
		 * session.setAttribute("member_email", dto.getMember_email());
		 * request.setAttribute("dto", dto);
		 * 
		 * RequestDispatcher rd = request.getRequestDispatcher("./idfind.jsp");
		 * rd.forward(request, response); } else {
		 * response.sendRedirect("id.jsp?error=2846"); }
		 */

		// 1. 이름, 이메일 오는지 확인
		// 2. 데이터베이스에 보내서 일치하는 id받아오기 - sql
		// 3. 받은 결과를 jsp에 붙이기 = rd
		// idfind.jsp

		// id.jsp ----> idFind Servlet --- > db ---> 결과값 idFind.jsp 붙이기
		// 보 이름,이메일....................있다없다,id.......붙이기
	}

}
