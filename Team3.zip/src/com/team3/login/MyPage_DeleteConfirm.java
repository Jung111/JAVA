package com.team3.login;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/deleteconfirm")
public class MyPage_DeleteConfirm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public MyPage_DeleteConfirm() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		
		
		JoinDAO dao = new JoinDAO();
		String id = (String) session.getAttribute("member_id");
		
		boolean a = dao.deleteConfirm(id, request.getParameter("member_pw"));
		if(a) {
			dao.myDeleteData(id);
			session.invalidate();
			response.sendRedirect("./index.jsp");
		}else {
			response.sendRedirect("./mypage.jsp");
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
