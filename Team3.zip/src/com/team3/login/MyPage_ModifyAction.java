package com.team3.login;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/mypagemodifyaction")
public class MyPage_ModifyAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public MyPage_ModifyAction() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();
		
		
		JoinDAO dao = new JoinDAO();
		String id = (String) session.getAttribute("member_id");
		
		dao.myModifyData(request.getParameter("member_pw"), request.getParameter("member_nickname"), request.getParameter("member_email"), request.getParameter("member_birth"), request.getParameter("member_ph"),
				id);
		response.sendRedirect("./mypagedelete");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
