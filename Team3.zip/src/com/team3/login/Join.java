package com.team3.login;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/join")
public class Join extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Join() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	@SuppressWarnings("unused")
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String method = request.getMethod();
		System.out.println(method);

		String name = request.getParameter("name");
		String nickname = request.getParameter("nickname");
		String ph0 = request.getParameter("ph0");
		String ph1 = request.getParameter("ph1");
		String ph2 = request.getParameter("ph2");
		String ph = ph0 + ph1 + ph2;
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String birth = request.getParameter("birth");
		String email = request.getParameter("email")+"@"+request.getParameter("email2");
		
		System.out.println(name + "_" + nickname + "_" + ph + "_" + id + "_" + pw + "_" + birth + "_" + email);

		JoinDAO dao = new JoinDAO();
		JoinDTO dto = new JoinDTO();
		dto.setMember_id(id);
		dto.setMember_name(name);
		dto.setMember_nickname(nickname);
		dto.setMember_ph(ph);
		dto.setMember_pw(pw);
		dto.setMember_birth(birth);
		dto.setMember_email(email);
		dao.join(dto);
		response.sendRedirect("./join2.jsp");
	}
}
