package com.team3.login;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private JoinDAO dao = new JoinDAO();

	public Login() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		// System.out.println("GET방식입니다.");
		response.sendRedirect("index.jsp");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// System.out.println("POST방식입니다");
		// doGet(request, response);
		// DB에서 id/pw가 있다면 로그인 시키고, 없으면 다시 index로 던지기
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id");
		String pw = request.getParameter("passwd");
		// System.out.println(id + ":" + pw);

		if (id.length() >= 3 && pw.length() >= 4) {
			// 로직은 여기에...
			// System.out.println("id나 pw가 4자 이상이거나, 비어있지 않아요.");
			// db에 질의하기
			// DTO / DAO
			JoinDTO dto = new JoinDTO();
			dto.setMember_id(id);
			dto.setMember_pw(pw);
			// System.out.println(dto.getMember_name()); //null

			dto = dao.login(dto);
			// System.out.println(dto.getMember_name()); //데이터베이스가 일을 합니다.
			// System.out.println(dto.getMember_no());//데이터베이스에서 오는 값.

			if (dto.getMember_nickname() != null && dto.getMember_no() > 0 && dto.getMember_grade() != 1) {
				// id pw가 일치했을 때 = main.jsp
				// session
				HttpSession session = request.getSession();
				session.setAttribute("member_id", dto.getMember_id());
				session.setAttribute("member_name", dto.getMember_name());
				session.setAttribute("member_no", dto.getMember_no());
				session.setAttribute("member_grade", dto.getMember_grade());
				session.setAttribute("member_nickname", dto.getMember_nickname());
				response.sendRedirect("./index.jsp");
			} else if (dto.getMember_grade() == 1) {
				response.sendRedirect("./main?error=2020");
			} else if (dto.getMember_nickname() == null && dto.getMember_no() == 0){
				response.sendRedirect("main?error=2846");// 비정상로그인
			}

		} else {
			// id pw가 불일치 때 = index.jsp
			response.sendRedirect("main?error=1059");// 비정상로그인
		}
	}

}
