package com.team3.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.team3.db.DBConn;

public class JoinDAO implements Maria {

	@Override
	public ArrayList<JoinDTO> list() {

		return null;
	}

	@Override
	public void join(JoinDTO dto) {
		Connection con = DBConn.getInstance().getConnection();
		PreparedStatement pstmt = null;
		String sql = "INSERT INTO member (member_id,member_pw,member_nickname,member_ph,member_birth,member_email,member_name)"
				+ "VALUES (?,?,?,?,?,?,?)";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getMember_id());
			pstmt.setString(2, dto.getMember_pw());
			pstmt.setString(3, dto.getMember_nickname());
			pstmt.setString(4, dto.getMember_ph());
			pstmt.setString(5, dto.getMember_birth());
			pstmt.setString(6, dto.getMember_email());
			pstmt.setString(7, dto.getMember_name());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}

		}

	}

	public int idCheck(String id) {
		Connection con = DBConn.getInstance().getConnection();
		String sql = "select count(*) from member where member_id=?";
		PreparedStatement pstmt = null;
		int result = 1;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				result = rs.getInt(1);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
				return result;
			}
		}
		return result;
	}

	public ArrayList<String> idFind(String name, String email) {
		Connection con = DBConn.getInstance().getConnection();
		String sql = "select count(*) as count, member_id from member where member_name=? and member_email=?";
		PreparedStatement pstmt = null;

		ArrayList<String> result = new ArrayList<String>();
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, email);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				result.add(rs.getString("count"));
				result.add(rs.getString("member_id"));

				System.out.println(result);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
				return result;
			}
		}
		return result;
	}

	public int pwcheck(String pw) {
		Connection con = DBConn.getInstance().getConnection();
		String sql = "select count (*) member_pw from member where member_id=? and member_pw=?";
		PreparedStatement pstmt = null;
		int result = 1;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, pw);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				result = rs.getInt(1);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
				return result;
			}
		}
		return result;
	}

	public ArrayList<String> pwFind(String id, String ph) {
		Connection con = DBConn.getInstance().getConnection();
		String sql = "select count(*) as count, member_pw from member where member_id=? and member_ph=?";
		PreparedStatement pstmt = null;
		ArrayList<String> result = new ArrayList<String>();
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, ph);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				result.add(rs.getString("count"));
				result.add(rs.getString("member_pw"));

				System.out.println(result);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
				return result;
			}
		}
		return result;
	}

	public int nickCheck(String nickname) {
		Connection con = DBConn.getInstance().getConnection();
		String sql = "select count(*) from member where member_nickname=?";
		PreparedStatement pstmt = null;
		int result = 1;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, nickname);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				result = rs.getInt(1);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
				return result;
			}
		}
		return result;
	}

	public int phCheck(String ph) {
		Connection con = DBConn.getInstance().getConnection();
		String sql = "select count(*) from member where member_ph=?";
		PreparedStatement pstmt = null;
		int result = 1;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, ph);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				result = rs.getInt(1);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
				return result;
			}
		}
		return result;
	}

	public int emailCheck(String email) {
		Connection con = DBConn.getInstance().getConnection();
		String sql = "select count(*) from member where member_email=?";
		PreparedStatement pstmt = null;
		int result = 1;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, email);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				result = rs.getInt(1);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
				return result;
			}
		}
		return result;
	}

	public void createAcoount(JoinDTO dto) {
		// TODO Auto-generated method stub

	}

	@Override
	public JoinDTO detail(JoinDTO dto) {
		// TODO Auto-generated method stub
		return null;
	}

	// 회원정보 수정 - 수정하기
	public void myModifyData(String member_pw, String member_nickname, String member_email, String member_birth,
			String member_ph, String member_id) {

		Connection con = DBConn.getInstance().getConnection();
		String sql = "UPDATE member SET member_pw=?, member_nickname=?, member_email=?, member_birth=?, member_ph=? "
				+ "WHERE member_id=?";
		PreparedStatement pstmt = null;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, member_pw);
			pstmt.setString(2, member_nickname);
			pstmt.setString(3, member_email);
			pstmt.setString(4, member_birth);
			pstmt.setString(5, member_ph);
			pstmt.setString(6, member_id);
			pstmt.execute();
		} catch (Exception e) {
			System.out.println("modifyData err : " + e);
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	// 비밀번호 확인
	public boolean deleteConfirm(String member_id, String member_pw) {

		boolean b = false;
		Connection con = DBConn.getInstance().getConnection();
		String sql = "SELECT * FROM member where member_id = ? and member_pw = ?";
		PreparedStatement pstmt = null;

		try {
			pstmt = con.prepareStatement(sql);

			pstmt.setString(1, member_id);
			pstmt.setString(2, member_pw);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next())
				b = true;

		} catch (Exception e) {
			System.out.println("deleteConfirm err : " + e);
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return b;
	}

	// 회원정보 삭제
	public boolean myDeleteData(String id) {
		boolean b = false;

		Connection con = DBConn.getInstance().getConnection();
		String sql = "DELETE FROM member WHERE member_id=?";
		PreparedStatement pstmt = null;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			int re = pstmt.executeUpdate();
			if (re > 0)
				b = true;

		} catch (Exception e) {
			System.out.println("modifyData err : " + e);
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return b;
	}

// 로그인 정보 받아오기
	public JoinDTO getData(String member_id) {

		ResultSet rs;
		Connection con = DBConn.getInstance().getConnection();
		String sql = "select  * from member where member_id=?";
		PreparedStatement pstmt = null;

		JoinDTO dto = new JoinDTO();
		try {

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, member_id);
			rs = pstmt.executeQuery();
			if (rs.next()) {

				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setMember_id(rs.getString("member_id"));
				dto.setMember_email(rs.getString("member_email"));
				dto.setMember_name(rs.getString("member_name"));
				dto.setMember_birth(rs.getString("member_birth"));
				dto.setMember_ph(rs.getString("member_ph"));
				dto.setMember_pw(rs.getString("member_pw"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return dto;
	}

	public JoinDTO login(JoinDTO dto) {
		// jar연결하기
		// conn연결
		Connection con = DBConn.getInstance().getConnection();
		// sql
		String sql = "SELECT COUNT(*), member_name, member_no, member_id, member_grade, member_nickname FROM member WHERE member_id=? AND member_pw=?";
		// pstmt
		PreparedStatement pstmt = null;

		// 내보낼 DTO는 파라미터로 오는 dto를 사용하도록 하겠습니다.

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getMember_id());
			pstmt.setString(2, dto.getMember_pw());
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				if (rs.getInt(1) != 0) {
					dto.setMember_id(rs.getString("member_id"));
					dto.setMember_nickname(rs.getString("member_name"));
					dto.setMember_no(rs.getInt("member_no"));
					dto.setMember_grade(rs.getInt("member_grade"));
					dto.setMember_nickname(rs.getString("member_nickname"));
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return dto;
	}

}
