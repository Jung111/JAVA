package com.team3.login;

import java.util.ArrayList;

public interface Maria {

	public ArrayList<JoinDTO> list();

	public JoinDTO detail(JoinDTO dto);

	public void join(JoinDTO dto);

	
	
	


}
