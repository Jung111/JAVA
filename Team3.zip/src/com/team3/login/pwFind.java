package com.team3.login;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/pwfind")
public class pwFind extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public pwFind() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		if (request.getParameter("id") != null && request.getParameter("ph") != null) {
			String id = request.getParameter("id");
			String ph = request.getParameter("ph");
			JoinDAO dao = new JoinDAO();
			ArrayList<String> result = dao.pwFind(id, ph);
			request.setAttribute("dto", result);
			RequestDispatcher rd = request.getRequestDispatcher("./pwfind.jsp");
			rd.forward(request, response);
		} else {
			System.out.println("id 와 전화번호를 다시입력해주세요");
		}

		doGet(request, response);
	}

}
