package com.team3.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConn {
	private static DBConn dbConn = new DBConn();

	public static DBConn getInstance() {
		return dbConn;
	}

	public Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName("org.mariadb.jdbc.Driver");
			String url = "jdbc:mariadb://220.70.33.29:3306/team3";
			conn = DriverManager.getConnection(url, "team3", "1234");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
}
