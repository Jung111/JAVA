package com.team3.board;

public class MarketBoardDTO {
	private int M_no, mboard_views, count, member_no, comments, rowno;
	private String mboard_title, mboard_content, mboard_date, member_id, mboard_file, member_nickname;
	public int getMboard_views() {
		return mboard_views;
	}
	public void setMboard_views(int mboard_views) {
		this.mboard_views = mboard_views;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getMember_no() {
		return member_no;
	}
	public void setMember_no(int member_no) {
		this.member_no = member_no;
	}
	public int getComments() {
		return comments;
	}
	public void setComments(int comments) {
		this.comments = comments;
	}
	public int getRowno() {
		return rowno;
	}
	public void setRowno(int rowno) {
		this.rowno = rowno;
	}
	public String getMboard_title() {
		return mboard_title;
	}
	public void setMboard_title(String mboard_title) {
		this.mboard_title = mboard_title;
	}
	public String getMboard_content() {
		return mboard_content;
	}
	public void setMboard_content(String mboard_content) {
		this.mboard_content = mboard_content;
	}
	public String getMboard_date() {
		return mboard_date;
	}
	public void setMboard_date(String mboard_date) {
		this.mboard_date = mboard_date;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getMboard_file() {
		return mboard_file;
	}
	public void setMboard_file(String mboard_file) {
		this.mboard_file = mboard_file;
	}
	public String getMember_nickname() {
		return member_nickname;
	}
	public void setMember_nickname(String member_nickname) {
		this.member_nickname = member_nickname;
	}
	public int getM_no() {
		return M_no;
	}
	public void setM_no(int m_no) {
		M_no = m_no;
	}

}
