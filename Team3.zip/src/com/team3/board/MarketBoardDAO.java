package com.team3.board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.team3.db.DBConn;

public class MarketBoardDAO {
	// 게시물list---------------------------------------------------------
	public ArrayList<MarketBoardDTO> list(int page) {
		ArrayList<MarketBoardDTO> list = new ArrayList<MarketBoardDTO>();

		Connection conn = DBConn.getInstance().getConnection();

		PreparedStatement pstmt = null;
		String sql = "select * from marketboardview limit ?, 10";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, page);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				MarketBoardDTO dto = new MarketBoardDTO();
				dto.setM_no(rs.getInt("m_no"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setMboard_title(rs.getString("mboard_title"));
				dto.setMboard_content(rs.getString("mboard_content"));
				
				String date = rs.getString("mboard_date").substring(0, 16);
						
				dto.setMboard_date(date);
				dto.setMboard_views(rs.getInt("mboard_views"));
				dto.setCount(rs.getInt("count"));
				dto.setComments(rs.getInt("comments"));
				dto.setRowno(rs.getInt("rowno"));
				list.add(dto);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}
	
	//조회수메소드----------------------------------------------
	public void countUp(int mno) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "UPDATE marketboard SET mboard_views=mboard_views+1 WHERE m_no=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, mno);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != pstmt) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	// 상세보기---------------------------------------------------------
	public MarketBoardDTO detail(int mno) {

		Connection conn = DBConn.getInstance().getConnection();

		PreparedStatement pstmt = null;
		String sql = "select * from marketboardview WHERE m_no =" + mno;
		MarketBoardDTO dto = new MarketBoardDTO();

		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				dto.setM_no(rs.getInt("m_no"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setMboard_title(rs.getString("mboard_title"));
				dto.setMboard_content(rs.getString("mboard_content"));
				
				String date = rs.getString("mboard_date").substring(0, 16);
				dto.setMboard_date(date);
				
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setMboard_views(rs.getInt("mboard_views"));
				dto.setMboard_file(rs.getString("mboard_file"));
				dto.setMember_no(rs.getInt("member_no"));
				dto.setComments(rs.getInt("comments"));
				
				countUp(mno);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return dto;
	}

	// modify에 사용-------------------------------------------------
	public MarketBoardDTO detail(int mno, int mno2) {

		Connection conn = DBConn.getInstance().getConnection();

		PreparedStatement pstmt = null;
		String sql = "select * from marketboardview WHERE m_no=? and member_no=?";
		MarketBoardDTO dto = new MarketBoardDTO();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, mno);
			pstmt.setInt(2, mno2);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				dto.setM_no(rs.getInt("m_no"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setMboard_title(rs.getString("mboard_title"));
				dto.setMboard_content(rs.getString("mboard_content"));
				dto.setMboard_date(rs.getString("mboard_date"));
				dto.setMboard_views(rs.getInt("mboard_views"));
				dto.setMboard_file(rs.getString("mboard_file"));
				dto.setMember_no(rs.getInt("member_no"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return dto;
	}

	// 삭제---------------------------------------------------------
	public void delete(String bno) {
		Connection conn = DBConn.getInstance().getConnection();

		PreparedStatement pstmt = null;
		String sql = "DELETE FROM marketboard WHERE m_no=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bno);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	// 글쓰기---------------------------------------------------------
	public void write(MarketBoardDTO dto, String board) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "";
		System.out.println("file : "+dto.getMboard_file());
		if (dto.getMboard_file() != null) {
			sql = "INSERT INTO " + board + " (mboard_title, mboard_content, mboard_file, member_no) "
					+ "VALUES(?, ?, ?, ?)";
		} else {
			sql = "INSERT INTO " + board + " (mboard_title, mboard_content, member_no) VALUES(?, ?, ?)";
		}

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getMboard_title());
			pstmt.setString(2, dto.getMboard_content());

			if (dto.getMboard_file() != null) {
				pstmt.setString(3, dto.getMboard_file());
				pstmt.setInt(4, dto.getMember_no());

			} else {
				pstmt.setInt(3, dto.getMember_no());
			}

			pstmt.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}
	//댓글 작성------------------------------------
	public void commentInsert(MarketCommentDTO dto) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "INSERT INTO mcomments (member_no, m_no, mcontent) VALUES (?, ?, ?)";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, dto.getMember_no());
			pstmt.setInt(2, dto.getM_no());
			pstmt.setString(3, dto.getMcontent());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	//댓글detail----------------------------
	public ArrayList<MarketCommentDTO> comments(int mno) {
		ArrayList<MarketCommentDTO> comment = new ArrayList<MarketCommentDTO>();
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "SELECT * FROM mcommentsview WHERE m_no=?";
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, mno);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				MarketCommentDTO dto = new MarketCommentDTO();
				dto.setM_no(rs.getInt("m_no"));
				dto.setMcontent(rs.getString("mcontent"));
				String date = rs.getString("mdate").substring(0, 16);
				
				dto.setMdate(date);
				
//				dto.setFdate(rs.getString("fdate"));
				
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setMember_no(rs.getInt("member_no"));
				dto.setmc_no(rs.getInt("mc_no"));
				comment.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return comment;
	}
	//댓글한줄----------------------------
	public MarketCommentDTO commentpick(int mc_no) {
		MarketCommentDTO dto = new MarketCommentDTO();
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "SELECT * FROM mcommentsview WHERE mc_no=?";
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, mc_no);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				dto.setM_no(rs.getInt("m_no"));
				dto.setMcontent(rs.getString("mcontent"));
				dto.setMdate(rs.getString("mdate"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setMember_no(rs.getInt("member_no"));
				dto.setmc_no(rs.getInt("mc_no"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return dto;
	}


	public void marketcommentdel(String mc_no) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "DELETE FROM mcomments WHERE mc_no=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mc_no);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	//게시글 수정----------------------------------------
	public void marketmodify(MarketBoardDTO dto) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "UPDATE marketboard SET mboard_title=?, mboard_content=? WHERE m_no=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getMboard_title());
			pstmt.setString(2, dto.getMboard_content());
			pstmt.setInt(3, dto.getM_no());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	//댓글수정---------------------------------------------------
	public void commentupdate(MarketCommentDTO dto) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "UPDATE mcomments SET mcontent=? WHERE mc_no=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getMcontent());
			pstmt.setInt(2, dto.getmc_no());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public ArrayList<MarketBoardDTO> searchlist(String val) {
		ArrayList<MarketBoardDTO> list = new ArrayList<MarketBoardDTO>();

		Connection conn = DBConn.getInstance().getConnection();

		PreparedStatement pstmt = null;
		String sql = "SELECT * FROM marketboardview WHERE mboard_content LIKE ? OR mboard_title LIKE ? OR member_nickname LIKE ? limit 10";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%"+ val +"%");
			pstmt.setString(2, "%"+ val +"%");
			pstmt.setString(3, "%"+ val +"%");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				MarketBoardDTO dto = new MarketBoardDTO();
				dto.setM_no(rs.getInt("m_no"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setMboard_title(rs.getString("mboard_title"));
				dto.setMboard_content(rs.getString("mboard_content"));
				
				String date = rs.getString("mboard_date").substring(0, 16);
						
				dto.setMboard_date(date);
//				dto.setFboard_date(rs.getString("fboard_date"));
				dto.setMboard_views(rs.getInt("mboard_views"));
				dto.setCount(rs.getInt("count"));
				dto.setComments(rs.getInt("comments"));
				dto.setRowno(rs.getInt("rowno"));
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	public ArrayList<MarketBoardDTO> rank() {
		ArrayList<MarketBoardDTO> rank = new ArrayList<MarketBoardDTO>();
		// DBConn Conn
		Connection conn = DBConn.getInstance().getConnection();
		// sql
		String sql = "SELECT * FROM marketboardview ORDER BY mboard_views DESC LIMIT 10";
		// pstmt
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				MarketBoardDTO dto = new MarketBoardDTO();
				dto.setM_no(rs.getInt("m_no"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setMboard_title(rs.getString("mboard_title"));
				dto.setMboard_content(rs.getString("mboard_content"));
				dto.setMboard_date(rs.getString("mboard_date"));
				dto.setMboard_views(rs.getInt("mboard_views"));
				dto.setMboard_file(rs.getString("mboard_file"));
				dto.setMember_no(rs.getInt("member_no"));
				dto.setCount(rs.getInt("count"));
				dto.setComments(rs.getInt("comments"));
				rank.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return rank;
	}

	public String findFile(int bno) {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(int bno, int i) {
		// TODO Auto-generated method stub
		
	}

	

}
