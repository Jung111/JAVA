package com.team3.board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.team3.db.DBConn;

public class FreeBoardDAO {
	// 게시물list---------------------------------------------------------
	public ArrayList<FreeBoardDTO> list(int page) {
		ArrayList<FreeBoardDTO> list = new ArrayList<FreeBoardDTO>();

		Connection conn = DBConn.getInstance().getConnection();

		PreparedStatement pstmt = null;
		String sql = "select * from freeboardview limit ?, 10";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, page);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				FreeBoardDTO dto = new FreeBoardDTO();
				dto.setFboard_no(rs.getInt("fboard_no"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setFboard_title(rs.getString("fboard_title"));
				dto.setFboard_content(rs.getString("fboard_content"));
				
				String date = rs.getString("fboard_date").substring(0, 16);
						
				dto.setFboard_date(date);
//				dto.setFboard_date(rs.getString("fboard_date"));
				dto.setFboard_views(rs.getInt("fboard_views"));
				dto.setCount(rs.getInt("count"));
				dto.setComments(rs.getInt("comments"));
				list.add(dto);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}
	
	//조회수메소드----------------------------------------------
	public void countUp(int fno) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "UPDATE freeboard SET fboard_views=fboard_views+1 WHERE fboard_no=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, fno);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != pstmt) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	// 상세보기---------------------------------------------------------
	public FreeBoardDTO detail(int fno) {

		Connection conn = DBConn.getInstance().getConnection();

		PreparedStatement pstmt = null;
		String sql = "select * from freeboardview WHERE fboard_no =" + fno;
		FreeBoardDTO dto = new FreeBoardDTO();

		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				dto.setFboard_no(rs.getInt("fboard_no"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setFboard_title(rs.getString("fboard_title"));
				dto.setFboard_content(rs.getString("fboard_content"));
				
				String date = rs.getString("fboard_date").substring(0, 16);
				dto.setFboard_date(date);
				
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setFboard_views(rs.getInt("fboard_views"));
				dto.setFboard_file(rs.getString("fboard_file"));
				dto.setMember_no(rs.getInt("member_no"));
				dto.setComments(rs.getInt("comments"));
				
				countUp(fno);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return dto;
	}

	// modify에 사용-------------------------------------------------
	public FreeBoardDTO detail(int fno, int mno) {

		Connection conn = DBConn.getInstance().getConnection();

		PreparedStatement pstmt = null;
		String sql = "select * from freeboardview WHERE fboard_no=? and member_no=?";
		FreeBoardDTO dto = new FreeBoardDTO();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, fno);
			pstmt.setInt(2, mno);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				dto.setFboard_no(rs.getInt("fboard_no"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setFboard_title(rs.getString("fboard_title"));
				dto.setFboard_content(rs.getString("fboard_content"));
				dto.setFboard_date(rs.getString("fboard_date"));
				dto.setFboard_views(rs.getInt("fboard_views"));
				dto.setFboard_file(rs.getString("fboard_file"));
				dto.setMember_no(rs.getInt("member_no"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return dto;
	}

	// 삭제---------------------------------------------------------
	public void delete(String bno) {
		Connection conn = DBConn.getInstance().getConnection();

		PreparedStatement pstmt = null;
		String sql = "DELETE FROM freeboard WHERE fboard_no=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bno);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	// 글쓰기---------------------------------------------------------
	public void write(FreeBoardDTO dto, String board) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "";
		System.out.println("file : "+dto.getFboard_file());
		if (dto.getFboard_file() != null) {
			sql = "INSERT INTO " + board + " (fboard_title, fboard_content, fboard_file, member_no) "
					+ "VALUES(?, ?, ?, ?)";
		} else {
			sql = "INSERT INTO " + board + " (fboard_title, fboard_content, member_no) VALUES(?, ?, ?)";
		}

		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getFboard_title());
			pstmt.setString(2, dto.getFboard_content());

			if (dto.getFboard_file() != null) {
				pstmt.setString(3, dto.getFboard_file());
				pstmt.setInt(4, dto.getMember_no());

			} else {
				pstmt.setInt(3, dto.getMember_no());
			}

			pstmt.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}
	//댓글 작성------------------------------------
	public void commentInsert(FreeCommentDTO dto) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "INSERT INTO fcomments (member_no, fboard_no, fcontent) VALUES (?, ?, ?)";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, dto.getMember_no());
			pstmt.setInt(2, dto.getFboard_no());
			pstmt.setString(3, dto.getFcontent());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	//댓글detail----------------------------
	public ArrayList<FreeCommentDTO> comments(int fno) {
		ArrayList<FreeCommentDTO> comment = new ArrayList<FreeCommentDTO>();
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "SELECT * FROM fcommentsview WHERE fboard_no=?";
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, fno);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				FreeCommentDTO dto = new FreeCommentDTO();
				dto.setFboard_no(rs.getInt("fboard_no"));
				dto.setFcontent(rs.getString("fcontent"));
				String date = rs.getString("fdate").substring(0, 16);
				
				dto.setFdate(date);
				
//				dto.setFdate(rs.getString("fdate"));
				
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setMember_no(rs.getInt("member_no"));
				dto.setF_no(rs.getInt("f_no"));
				comment.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return comment;
	}
	//댓글한줄----------------------------
	public FreeCommentDTO commentpick(int f_no) {
		FreeCommentDTO dto = new FreeCommentDTO();
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "SELECT * FROM fcommentsview WHERE f_no=?";
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, f_no);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				dto.setFboard_no(rs.getInt("fboard_no"));
				dto.setFcontent(rs.getString("fcontent"));
				dto.setFdate(rs.getString("fdate"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setMember_no(rs.getInt("member_no"));
				dto.setF_no(rs.getInt("f_no"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return dto;
	}
	//댓글삭제--------------------------------------------------
	public void freecommentdel(String f_no) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "DELETE FROM fcomments WHERE f_no=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, f_no);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	//게시글 수정----------------------------------------
	public void freemodify(FreeBoardDTO dto) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "UPDATE freeboard SET fboard_title=?, fboard_content=? WHERE fboard_no=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getFboard_title());
			pstmt.setString(2, dto.getFboard_content());
			pstmt.setInt(3, dto.getFboard_no());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	//댓글수정---------------------------------------------------
	public void commentupdate(FreeCommentDTO dto) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "UPDATE fcomments SET fcontent=? WHERE f_no=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getFcontent());
			pstmt.setInt(2, dto.getF_no());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	public ArrayList<FreeBoardDTO> rank() {
		ArrayList<FreeBoardDTO> rank = new ArrayList<FreeBoardDTO>();
		// DBConn Conn
		Connection conn = DBConn.getInstance().getConnection();
		// sql
		String sql = "SELECT * FROM freeboardview ORDER BY fboard_views DESC LIMIT 10";
		// pstmt
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				FreeBoardDTO dto = new FreeBoardDTO();
				dto.setFboard_no(rs.getInt("fboard_no"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setFboard_title(rs.getString("fboard_title"));
				dto.setFboard_content(rs.getString("fboard_content"));
				dto.setFboard_date(rs.getString("fboard_date"));
				dto.setFboard_views(rs.getInt("fboard_views"));
				dto.setFboard_file(rs.getString("fboard_file"));
				dto.setMember_no(rs.getInt("member_no"));
				dto.setCount(rs.getInt("count"));
				dto.setComments(rs.getInt("comments"));
				rank.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return rank;
	}


}
