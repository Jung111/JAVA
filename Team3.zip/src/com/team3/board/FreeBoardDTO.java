package com.team3.board;

public class FreeBoardDTO {
	private int fboard_no, fboard_views, count, member_no, comments;
	private String fboard_title, fboard_content, fboard_date, member_id, fboard_file, member_nickname;

	public int getFboard_no() {
		return fboard_no;
	}

	public void setFboard_no(int fboard_no) {
		this.fboard_no = fboard_no;
	}

	public int getFboard_views() {
		return fboard_views;
	}

	public void setFboard_views(int fboard_views) {
		this.fboard_views = fboard_views;
	}

	public String getFboard_title() {
		return fboard_title;
	}

	public void setFboard_title(String fboard_title) {
		this.fboard_title = fboard_title;
	}

	public String getFboard_content() {
		return fboard_content;
	}

	public void setFboard_content(String fboard_content) {
		this.fboard_content = fboard_content;
	}

	public String getFboard_date() {
		return fboard_date;
	}

	public void setFboard_date(String fboard_date) {
		this.fboard_date = fboard_date;
	}

	public String getMember_id() {
		return member_id;
	}

	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getFboard_file() {
		return fboard_file;
	}

	public void setFboard_file(String fboard_file) {
		this.fboard_file = fboard_file;
	}

	public int getMember_no() {
		return member_no;
	}

	public void setMember_no(int member_no) {
		this.member_no = member_no;
	}

	public int getComments() {
		return comments;
	}

	public void setComments(int comments) {
		this.comments = comments;
	}

	public String getMember_nickname() {
		return member_nickname;
	}

	public void setMember_nickname(String member_nickname) {
		this.member_nickname = member_nickname;
	}

}
