package com.team3.board;
//DAO : 

//DTO / VO : 

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.team3.db.DBConn;

public class MemberDAO {
	public HashMap<String, Object> login(HashMap<String, Object> map) {
		HashMap<String, Object> result = new HashMap<String, Object>();
		// Conn객체, 연결
		Connection con = DBConn.getInstance().getConnection();
		// pstmt
		PreparedStatement pstmt = null;
		// SQL
		String sql = "SELECT COUNT(*) as count, member_nickname, member_no, member_grade "
				+ "FROM login_view WHERE member_id=? AND member_pw=?";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setObject(1, map.get("member_id"));// 로그인페이지 - 서블릿 - DAO
			pstmt.setObject(2, map.get("member_pw"));

			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				result.put("count", rs.getInt("count")); // count = 1
				result.put("member_nickname", rs.getString("member_nickname"));
				result.put("member_no", rs.getInt("member_no"));
				result.put("member_grade", rs.getInt("member_grade"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	public HashMap<String, Object> myInfo(int member_no) {
		HashMap<String, Object> myInfo = new HashMap<String, Object>();
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "select member_no, member_nickname, member_id, member_email from member where member_no=?";
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, member_no);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				myInfo.put("member_no", rs.getInt("member_no"));
				myInfo.put("member_nickname", rs.getInt("member_nickname"));
				myInfo.put("member_id", rs.getInt("member_id"));
				myInfo.put("member_email", rs.getInt("member_email"));
				myInfo.put("member_grade", rs.getObject("member_grade"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return myInfo;
	}

	public ArrayList<HashMap<String, Object>> memberList() {
		Connection con = DBConn.getInstance().getConnection();
		String sql = "select member_no, member_nickname, member_id, member_email, member_grade from member";
		ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();

		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				HashMap<String, Object> ele = new HashMap<String, Object>();
				ele.put("member_no", rs.getObject("member_no"));
				ele.put("member_nickname", rs.getObject("member_nickname"));
				ele.put("member_id", rs.getObject("member_id"));
				ele.put("member_email", rs.getObject("member_email"));
				ele.put("member_grade", rs.getObject("member_grade"));

				list.add(ele);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public void delete(int member_no) {
		Connection con = DBConn.getInstance().getConnection();
		String sql = "update member set member_grade = 1 where member_no=?";
		PreparedStatement pstmt = null;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, member_no);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void change(int member_grade, int member_no) {
		Connection con = DBConn.getInstance().getConnection();
		String sql = "update member set member_grade =? where member_no=?";
		PreparedStatement pstmt = null;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, member_grade);
			pstmt.setInt(2, member_no);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
