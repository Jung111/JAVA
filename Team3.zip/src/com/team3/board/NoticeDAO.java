package com.team3.board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.team3.db.DBConn;

public class NoticeDAO {

	public ArrayList<NoticeDTO> list(String noticeboard) {
		ArrayList<NoticeDTO> list = new ArrayList<NoticeDTO>();
		// DBConn Conn
		Connection conn = DBConn.getInstance().getConnection();
		// sql
		String sql = "";
		if (noticeboard == null || noticeboard.equals("noticeboard")) {
			noticeboard = "noticeboard";
			sql = "SELECT * FROM noticeview limit 10";

		} else if (noticeboard.equals("notice")) {
			sql = "SELECT * FROM noticeview limit 10";

		} else if (noticeboard.equals("free")) {
			sql = "SELECT * FROM freeboardview limit 10";

		} else if (noticeboard.equals("close")) {
			sql = "SELECT * FROM closeboardview limit 10";
		}
		// pstmt
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				NoticeDTO dto = new NoticeDTO();
				dto.setN_no(rs.getInt("n_no"));
				dto.setN_title(rs.getString("n_title"));
				String date = rs.getString("n_date").substring(0, 16);
				dto.setN_date(date);
				dto.setN_views(rs.getString("n_views"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setN_file(rs.getString("n_file"));

				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return list;
	}

	public ArrayList<NoticeDTO> list() {
		ArrayList<NoticeDTO> list = new ArrayList<NoticeDTO>();
		// DBConn Conn
		Connection conn = DBConn.getInstance().getConnection();
		// sql
		String sql = "SELECT * FROM noticeview limit 10";
		// pstmt
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				NoticeDTO dto = new NoticeDTO();
				dto.setN_no(rs.getInt("n_no"));
				dto.setN_title(rs.getString("n_title"));
				String date = rs.getString("n_date").substring(0, 16);
				dto.setN_date(date);
				dto.setN_views(rs.getString("n_views"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setN_file(rs.getString("n_file"));
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return list;
	}

	public void countUp(int bno) {
		Connection con = DBConn.getInstance().getConnection();
		String sql = "UPDATE noticeboard SET n_views=n_views+1 WHERE n_no=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bno);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	// detail
	public NoticeDTO detail(int bno) {
		NoticeDTO dto = new NoticeDTO();
		// con
		Connection con = DBConn.getInstance().getConnection();
		// sql
		String sql = "SELECT * FROM noticeview WHERE n_no=?";
		// pstmt
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bno);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				dto.setN_no(rs.getInt("n_no"));
				dto.setN_title(rs.getString("n_title"));
				dto.setN_content(rs.getString("n_content"));
				String date = rs.getString("n_date").substring(0, 16);
				dto.setN_date(date);
				dto.setN_views(rs.getString("n_views"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setMember_no(rs.getInt("member_no"));
				dto.setN_file(rs.getString("n_file"));
				countUp(bno);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dto;

	}

	// detail새로 만들었습니다. 파라미터가 두개~ 오버로드 사용해봤습니다.
	public NoticeDTO detail(int bno, int mno) {
		NoticeDTO dto = new NoticeDTO();
		// con
		Connection con = DBConn.getInstance().getConnection();
		// sql
		String sql = "SELECT * FROM noticeview WHERE n_no=? AND member_no=?";
		// pstmt
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bno);
			pstmt.setInt(2, mno);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				dto.setN_no(rs.getInt("n_no"));
				dto.setN_title(rs.getString("n_title"));
				dto.setN_content(rs.getString("n_content"));
				String date = rs.getString("n_date").substring(0, 16);
				dto.setN_date(date);
				dto.setN_views(rs.getString("n_views"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setMember_no(rs.getInt("member_no"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dto;

	}

	// 글쓰기
	public void write(NoticeDTO dto, String noticeboard) {
		// System.out.println(dto.getBoard_title());
		// System.out.println(dto.getBoard_content());
		// System.out.println(dto.getMember_name());
		// conn
		Connection conn = DBConn.getInstance().getConnection();
		// sql
		String sql = "";

		if (dto.getN_file() == null) {
			sql = "INSERT INTO " + noticeboard + " (n_title, n_content, member_no) VALUES(?, ?, ?)";
		} else {
			sql = "INSERT INTO " + noticeboard + " (n_title, n_content, n_file, member_no) " + "VALUES(?, ?, ?, ?)";
		}
		System.out.println(sql);
		// pstmt
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			// pstmt.setString(1, board);
			pstmt.setString(1, dto.getN_title());
			pstmt.setString(2, dto.getN_content());

			if (dto.getN_file() == null) {
				pstmt.setInt(3, dto.getMember_no());

			} else {
				pstmt.setString(3, dto.getN_file());
				pstmt.setInt(4, dto.getMember_no());
			}

			pstmt.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	// 수정하기
	public void modify(String n_title, String n_content, int n_no) {
		Connection con = DBConn.getInstance().getConnection();
		String sql = "UPDATE noticeboard SET n_title=?, n_content=? " + "WHERE n_no=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, n_title);
			pstmt.setString(2, n_content);
			pstmt.setInt(3, n_no);
			pstmt.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	// delete
	public void delete(int num, int member_no) {
		Connection con = DBConn.getInstance().getConnection();
		String sql = "DELETE FROM noticeboard WHERE n_no=? AND member_no=?";

		PreparedStatement pstmt = null;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setInt(2, member_no);
			pstmt.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	public String findFile(int bno) {
		String fileName = "";
		Connection con = DBConn.getInstance().getConnection();
		String sql = "select n_file from noticeboard where n_no=?";

		PreparedStatement pstmt = null;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bno);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				fileName = rs.getString("n_file");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return fileName;
	}

	public ArrayList<NoticeDTO> search(String word) {
		ArrayList<NoticeDTO> list = new ArrayList<NoticeDTO>();

		Connection conn = DBConn.getInstance().getConnection();

		PreparedStatement pstmt = null;
		String sql = "SELECT * FROM noticeview WHERE n_content LIKE ? OR n_title LIKE ? OR member_nickname LIKE ? limit 10";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + word + "%");
			pstmt.setString(2, "%" + word + "%");
			pstmt.setString(3, "%" + word + "%");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				NoticeDTO dto = new NoticeDTO();
				dto.setN_no(rs.getInt("n_no"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setN_title(rs.getString("n_title"));
				dto.setN_content(rs.getString("n_content"));

				String date = rs.getString("n_date").substring(0, 16);

				dto.setN_date(date);
				dto.setN_views(rs.getString("n_views"));
				dto.setCount(rs.getInt("count"));
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return list;
	}

	public ArrayList<NoticeDTO> list(int page) {
		ArrayList<NoticeDTO> list = new ArrayList<NoticeDTO>();
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "SELECT * FROM noticeview limit ?, 10";
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, page);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				NoticeDTO dto = new NoticeDTO();
				dto.setN_no(rs.getInt("n_no"));
				dto.setN_title(rs.getString("n_title"));
				String date = rs.getString("n_date").substring(0, 16);
				dto.setN_date(date);
				dto.setN_views(rs.getString("n_views"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setN_file(rs.getString("n_file"));
				dto.setMember_no(rs.getInt("member_no"));
				dto.setCount(rs.getInt("count"));
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return list;
	}
}
