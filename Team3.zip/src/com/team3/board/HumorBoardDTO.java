package com.team3.board;

public class HumorBoardDTO {
	private int hboard_no, hboard_views, count, member_no, comments;
	private String hboard_title, hboard_content, hboard_date, member_id, hboard_file, member_nickname;
	
	public int getHboard_no() {
		return hboard_no;
	}
	public void setHboard_no(int hboard_no) {
		this.hboard_no = hboard_no;
	}
	public int getHboard_views() {
		return hboard_views;
	}
	public void setHboard_views(int hboard_views) {
		this.hboard_views = hboard_views;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getMember_no() {
		return member_no;
	}
	public void setMember_no(int member_no) {
		this.member_no = member_no;
	}
	public int getComments() {
		return comments;
	}
	public void setComments(int comments) {
		this.comments = comments;
	}
	public String getHboard_title() {
		return hboard_title;
	}
	public void setHboard_title(String hboard_title) {
		this.hboard_title = hboard_title;
	}
	public String getHboard_content() {
		return hboard_content;
	}
	public void setHboard_content(String hboard_content) {
		this.hboard_content = hboard_content;
	}
	public String getHboard_date() {
		return hboard_date;
	}
	public void setHboard_date(String hboard_date) {
		this.hboard_date = hboard_date;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getHboard_file() {
		return hboard_file;
	}
	public void setHboard_file(String hboard_file) {
		this.hboard_file = hboard_file;
	}
	public String getMember_nickname() {
		return member_nickname;
	}
	public void setMember_nickname(String member_nickname) {
		this.member_nickname = member_nickname;
	}

}
