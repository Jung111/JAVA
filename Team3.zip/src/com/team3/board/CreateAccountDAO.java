package com.team3.board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.team3.db.DBConn;

public class CreateAccountDAO {
	public void createAcoount(MemberDTO dto) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "INSERT INTO member (member_id,member_pw,member_nickname,member_ph,member_birth,member_email,member_name)"
				+ "VALUES (?,?,?,?,?,?,?)";
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getMember_id());
			pstmt.setString(2, dto.getMember_pw());
			pstmt.setString(3, dto.getMember_nickname());
			pstmt.setString(4, dto.getMember_phone());
			pstmt.setString(5, dto.getMember_birth());
			pstmt.setString(6, dto.getMember_email());
			pstmt.setString(7, dto.getMember_name());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

}
