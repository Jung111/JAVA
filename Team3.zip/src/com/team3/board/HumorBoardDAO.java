package com.team3.board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.team3.db.DBConn;

public class HumorBoardDAO {

	public ArrayList<HumorBoardDTO> list(int page) {
		ArrayList<HumorBoardDTO> list = new ArrayList<HumorBoardDTO>();

		Connection conn = DBConn.getInstance().getConnection();

		PreparedStatement pstmt = null;
		String sql = "select * from humorboardview limit ?, 10";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, page);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				HumorBoardDTO dto = new HumorBoardDTO();
				dto.setHboard_no(rs.getInt("hboard_no"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setHboard_title(rs.getString("hboard_title"));
				dto.setHboard_content(rs.getString("hboard_content"));
				
				String date = rs.getString("hboard_date").substring(0, 16);
				
				dto.setHboard_date(date);
				
				dto.setHboard_views(rs.getInt("hboard_views"));
				dto.setCount(rs.getInt("count"));
				dto.setComments(rs.getInt("comments"));
				
				list.add(dto);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}
	
	public void countUp(int hno) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "UPDATE humorboard SET hboard_views=hboard_views+1 WHERE hboard_no=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, hno);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != pstmt) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	public HumorBoardDTO detail(int hno) {

		Connection conn = DBConn.getInstance().getConnection();

		PreparedStatement pstmt = null;
		String sql = "select * from humorboardview WHERE hboard_no =" + hno;
		HumorBoardDTO dto = new HumorBoardDTO();

		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				dto.setHboard_no(rs.getInt("hboard_no"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setHboard_title(rs.getString("hboard_title"));
				dto.setHboard_content(rs.getString("hboard_content"));
				String date = rs.getString("hboard_date").substring(0, 16);
				
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setHboard_date(date);
				dto.setHboard_views(rs.getInt("hboard_views"));
				dto.setHboard_file(rs.getString("hboard_file"));
				dto.setMember_no(rs.getInt("member_no"));
				dto.setComments(rs.getInt("comments"));
				
				countUp(hno);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return dto;
	}

	public ArrayList<HumorCommentDTO> comments(int hno) {
		ArrayList<HumorCommentDTO> comment = new ArrayList<HumorCommentDTO>();
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "SELECT * FROM hcommentsview WHERE hboard_no=?";
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, hno);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				HumorCommentDTO dto = new HumorCommentDTO();
				dto.setHboard_no(rs.getInt("hboard_no"));
				dto.setHcontent(rs.getString("hcontent"));
				
				String date = rs.getString("hdate").substring(0, 16);
				
				dto.setHdate(date);
				
//				dto.setHdate(rs.getString("hdate"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setMember_no(rs.getInt("member_no"));
				dto.setH_no(rs.getInt("h_no"));
				comment.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return comment;
	}

	public void write(HumorBoardDTO dto, String board) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "";
		System.out.println("file : "+dto.getHboard_file());
		if (dto.getHboard_file() != null) {
			sql = "INSERT INTO " + board + " (hboard_title, hboard_content, hboard_file, member_no) "
					+ "VALUES(?, ?, ?, ?)";
		} else {
			sql = "INSERT INTO " + board + " (hboard_title, hboard_content, member_no) VALUES(?, ?, ?)";
		}
		
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getHboard_title());
			pstmt.setString(2, dto.getHboard_content());

			if (dto.getHboard_file() != null) {
				pstmt.setString(3, dto.getHboard_file());
				pstmt.setInt(4, dto.getMember_no());

			} else {
				pstmt.setInt(3, dto.getMember_no());
			}

			pstmt.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
	}

	public void delete(String bno) {
		Connection conn = DBConn.getInstance().getConnection();

		PreparedStatement pstmt = null;
		String sql = "DELETE FROM humorboard WHERE hboard_no=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bno);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
	}

	public HumorBoardDTO detail(int hno, int mno) {

		Connection conn = DBConn.getInstance().getConnection();

		PreparedStatement pstmt = null;
		String sql = "select * from humorboardview WHERE hboard_no=? and member_no=?";
		HumorBoardDTO dto = new HumorBoardDTO();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, hno);
			pstmt.setInt(2, mno);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				dto.setHboard_no(rs.getInt("hboard_no"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setHboard_title(rs.getString("hboard_title"));
				dto.setHboard_content(rs.getString("hboard_content"));
				dto.setHboard_date(rs.getString("hboard_date"));
				dto.setHboard_views(rs.getInt("hboard_views"));
				dto.setHboard_file(rs.getString("hboard_file"));
				dto.setMember_no(rs.getInt("member_no"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return dto;
	}

	public void humormodify(HumorBoardDTO dto) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "UPDATE humorboard SET hboard_title=?, hboard_content=? WHERE hboard_no=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getHboard_title());
			pstmt.setString(2, dto.getHboard_content());
			pstmt.setInt(3, dto.getHboard_no());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void commentInsert(HumorCommentDTO dto) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "INSERT INTO hcomments (member_no, hboard_no, hcontent) VALUES (?, ?, ?)";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, dto.getMember_no());
			pstmt.setInt(2, dto.getHboard_no());
			pstmt.setString(3, dto.getHcontent());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}		
	}

	public HumorCommentDTO commentpick(int h_no) {
		HumorCommentDTO dto = new HumorCommentDTO();
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "SELECT * FROM hcommentsview WHERE h_no=?";
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, h_no);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				dto.setHboard_no(rs.getInt("hboard_no"));
				dto.setHcontent(rs.getString("hcontent"));
				dto.setHdate(rs.getString("hdate"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setMember_no(rs.getInt("member_no"));
				dto.setH_no(rs.getInt("h_no"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return dto;
	}

	public void commentupdate(HumorCommentDTO dto) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "UPDATE hcomments SET hcontent=? WHERE h_no=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getHcontent());
			pstmt.setInt(2, dto.getH_no());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}

	public void humorcommentdel(String h_no) {
		Connection conn = DBConn.getInstance().getConnection();
		String sql = "DELETE FROM hcomments WHERE h_no=?";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, h_no);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	public ArrayList<HumorBoardDTO> rank() {
		ArrayList<HumorBoardDTO> rank = new ArrayList<HumorBoardDTO>();
		// DBConn Conn
		Connection conn = DBConn.getInstance().getConnection();
		// sql
		String sql = "SELECT * FROM humorboardview ORDER BY hboard_views DESC LIMIT 10";
		// pstmt
		PreparedStatement pstmt = null;

		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				HumorBoardDTO dto = new HumorBoardDTO();
				dto.setHboard_no(rs.getInt("hboard_no"));
				dto.setMember_nickname(rs.getString("member_nickname"));
				dto.setHboard_title(rs.getString("hboard_title"));
				dto.setHboard_content(rs.getString("hboard_content"));
				dto.setHboard_date(rs.getString("hboard_date"));
				dto.setHboard_views(rs.getInt("hboard_views"));
				dto.setCount(rs.getInt("count"));
				dto.setComments(rs.getInt("comments"));
				dto.setMember_no(rs.getInt("member_no"));
				rank.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return rank;
	}

}
