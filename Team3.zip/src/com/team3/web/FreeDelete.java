package com.team3.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import com.team3.board.FreeBoardDAO;

@WebServlet("/freedelete")
public class FreeDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public FreeDelete() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
				
		if (request.getParameter("bno") != null && session.getAttribute("member_no") != null) {
			String bno = request.getParameter("bno");
			FreeBoardDAO dao = new FreeBoardDAO();
			dao.delete(bno);
		}
		response.sendRedirect("./freeboard");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("./freeboard");
	}

}
