package com.team3.web;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team3.board.FreeBoardDAO;
import com.team3.board.FreeBoardDTO;
import com.team3.util.FreeNumberCheck;


@WebServlet("/freeboard")
public class FreeBoard extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public FreeBoard() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int page = 1;
		if (request.getParameter("page") != null) {
			page = FreeNumberCheck.number(request.getParameter("page"));
		}
		
		FreeBoardDAO dao = new FreeBoardDAO();
		ArrayList<FreeBoardDTO> list = dao.list(page * 20 - 20);
		RequestDispatcher rd = request.getRequestDispatcher("./freeboard.jsp");
		request.setAttribute("list", list);
		request.setAttribute("count", list.get(0).getCount());
		request.setAttribute("page", page);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int page = 1;
		if (request.getParameter("page") != null) {
			page = FreeNumberCheck.number(request.getParameter("page"));
		}
		
		FreeBoardDAO dao = new FreeBoardDAO();
		ArrayList<FreeBoardDTO> list = dao.list(page * 20 - 20);
		RequestDispatcher rd = request.getRequestDispatcher("./freeboard.jsp");
		request.setAttribute("list", list);
		request.setAttribute("count", list.get(0).getCount());
		request.setAttribute("page", page);
		rd.forward(request, response);
	}

}
