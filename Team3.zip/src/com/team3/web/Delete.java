package com.team3.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.team3.board.MemberDAO;


@WebServlet("/delete")
public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Delete() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();

		if (session.getAttribute("member_grade") != null && request.getParameter("no") != null
				&& session.getAttribute("member_grade").equals(9)) {

			int member_no = Integer.parseInt(request.getParameter("no"));
			MemberDAO dao = new MemberDAO();
			dao.delete(member_no);

			response.sendRedirect("./memberlist");
		} else {
			response.sendRedirect("./board.jsp");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

}
