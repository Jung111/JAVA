package com.team3.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.team3.board.HumorBoardDAO;
import com.team3.board.HumorCommentDTO;
import com.team3.util.FreeNumberCheck;

@WebServlet("/humorcomment")
public class HumorComment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public HumorComment() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("./humorboard");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		if (request.getParameter("hno") != null 
				&& request.getParameter("hcontent") != null 
				&& FreeNumberCheck.numberCh(request.getParameter("hno"))) {
			HumorBoardDAO dao = new HumorBoardDAO();
			HumorCommentDTO dto = new HumorCommentDTO();
			dto.setHboard_no(Integer.parseInt(request.getParameter("hno")));
			dto.setHcontent(request.getParameter("hcontent"));
			dto.setMember_no((int)session.getAttribute("member_no"));
			
			dao.commentInsert(dto);
			
			response.sendRedirect("./humordetail?hno="+request.getParameter("hno"));
		} else {
			response.sendRedirect("./humordetail?hno="+request.getParameter("hno"));
		}
	}

}
