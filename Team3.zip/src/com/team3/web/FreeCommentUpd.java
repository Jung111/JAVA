package com.team3.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team3.board.FreeBoardDAO;
import com.team3.board.FreeCommentDTO;
import com.team3.util.FreeNumberCheck;

@WebServlet("/freecommentupd")
public class FreeCommentUpd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public FreeCommentUpd() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		FreeNumberCheck check = new FreeNumberCheck();
		int f_no = check.number(request.getParameter("f_no"));
	
		FreeBoardDAO dao = new FreeBoardDAO();
		FreeCommentDTO dto = dao.commentpick(f_no);
		RequestDispatcher rd = request.getRequestDispatcher("./freecommentupd.jsp");
		request.setAttribute("dto", dto);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		FreeNumberCheck check = new FreeNumberCheck();
		int f_no = check.number(request.getParameter("f_no"));
		
		FreeBoardDAO dao = new FreeBoardDAO();
		FreeCommentDTO dto = new FreeCommentDTO();
		dto.setF_no(f_no);
		dto.setFcontent(request.getParameter("content"));
		
		dao.commentupdate(dto);
		response.sendRedirect("./freedetail?fno="+request.getParameter("fno"));
	
	}

}
