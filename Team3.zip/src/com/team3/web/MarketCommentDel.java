package com.team3.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.team3.board.MarketBoardDAO;

@WebServlet("/marketcommentdel")
public class MarketCommentDel extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public MarketCommentDel() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//댓글 고유번호
		String mc_no = request.getParameter("mc_no");
		//게시글 고유번호
		String mno = request.getParameter("mno");
		
		String mno2 = request.getParameter("mno2");
		HttpSession session = request.getSession();
		
		MarketBoardDAO dao = new MarketBoardDAO();
		dao.marketcommentdel(mc_no);
		response.sendRedirect("./marketdetail?mno="+mno);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
