package com.team3.web;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team3.board.MarketBoardDAO;
import com.team3.board.MarketBoardDTO;
import com.team3.util.FreeNumberCheck;

@WebServlet("/marketboard")
public class MarketBoard extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public MarketBoard() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int page = 1;
		if (request.getParameter("page") != null) {
			page = FreeNumberCheck.number(request.getParameter("page"));
		}
		
		MarketBoardDAO dao = new MarketBoardDAO();
		ArrayList<MarketBoardDTO> list = dao.list(page * 10 - 10);
		RequestDispatcher rd = request.getRequestDispatcher("./marketboard.jsp");
		request.setAttribute("list", list);
		request.setAttribute("count", list.get(0).getCount());
		request.setAttribute("page", page);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int page = 1;
		if (request.getParameter("page") != null) {
			page = FreeNumberCheck.number(request.getParameter("page"));
		}
		
		MarketBoardDAO dao = new MarketBoardDAO();
		ArrayList<MarketBoardDTO> list = dao.list(page * 10 - 10);
		RequestDispatcher rd = request.getRequestDispatcher("./marketboard.jsp");
		request.setAttribute("list", list);
		request.setAttribute("count", list.get(0).getCount());
		request.setAttribute("page", page);
		rd.forward(request, response);
	}

}
