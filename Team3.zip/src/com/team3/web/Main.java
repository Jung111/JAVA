package com.team3.web;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team3.board.FreeBoardDAO;
import com.team3.board.FreeBoardDTO;
import com.team3.board.HumorBoardDAO;
import com.team3.board.HumorBoardDTO;
import com.team3.board.MarketBoardDAO;
import com.team3.board.MarketBoardDTO;
@WebServlet("/main")
public class Main extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Main() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		FreeBoardDAO freedao = new FreeBoardDAO();
		ArrayList<FreeBoardDTO> freerank = freedao.rank();
		request.setAttribute("freeboard", freerank);
		
		HumorBoardDAO humordao = new HumorBoardDAO();
		ArrayList<HumorBoardDTO> humorrank = humordao.rank();
		request.setAttribute("humorboard", humorrank);
		
		MarketBoardDAO marketdao = new MarketBoardDAO();// Model
		ArrayList<MarketBoardDTO> marketrank = marketdao.rank();
		request.setAttribute("marketboard", marketrank);
		
		RequestDispatcher rd = request.getRequestDispatcher("/main.jsp"); // View
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}








