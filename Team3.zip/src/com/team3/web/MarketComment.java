package com.team3.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.team3.board.MarketBoardDAO;
import com.team3.board.MarketCommentDTO;
import com.team3.util.FreeNumberCheck;

@WebServlet("/marketcomment")
public class MarketComment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public MarketComment() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		if (request.getParameter("mno") != null 
				&& request.getParameter("mcontent") != null 
				&& FreeNumberCheck.numberCh(request.getParameter("mno"))) {
			MarketBoardDAO dao = new MarketBoardDAO();
			MarketCommentDTO dto = new MarketCommentDTO();
			dto.setM_no(Integer.parseInt(request.getParameter("mno")));
			dto.setMcontent(request.getParameter("mcontent"));
			dto.setMember_no((int)session.getAttribute("member_no"));
			
			dao.commentInsert(dto);
			
			response.sendRedirect("./marketdetail?mno="+request.getParameter("mno"));
		} else {
			response.sendRedirect("./marketdetail?mno="+request.getParameter("mno"));
		}
		
	}

}
