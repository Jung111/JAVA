package com.team3.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.team3.board.FreeBoardDAO;
import com.team3.board.FreeCommentDTO;
import com.team3.util.FreeNumberCheck;

@WebServlet("/freecomment")
public class FreeComment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public FreeComment() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		if (request.getParameter("fno") != null 
				&& request.getParameter("fcontent") != null 
				&& FreeNumberCheck.numberCh(request.getParameter("fno"))) {
			FreeBoardDAO dao = new FreeBoardDAO();
			FreeCommentDTO dto = new FreeCommentDTO();
			dto.setFboard_no(Integer.parseInt(request.getParameter("fno")));
			dto.setFcontent(request.getParameter("fcontent"));
			dto.setMember_no((int)session.getAttribute("member_no"));
			
			dao.commentInsert(dto);
			
			response.sendRedirect("./freedetail?fno="+request.getParameter("fno"));
		} else {
			response.sendRedirect("./freedetail?fno="+request.getParameter("fno"));
		}
		
	}

}
