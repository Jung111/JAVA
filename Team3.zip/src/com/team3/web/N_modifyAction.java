package com.team3.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team3.board.NoticeDAO;

@WebServlet("/n_modifyaction")
public class N_modifyAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public N_modifyAction() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		NoticeDAO dao = new NoticeDAO();
		dao.modify(request.getParameter("title"), request.getParameter("content"),
				Integer.parseInt(request.getParameter("n_no")));
		response.sendRedirect("./n_detail?bno=" + Integer.parseInt(request.getParameter("n_no")));
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
