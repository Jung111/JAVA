package com.team3.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team3.board.CreateAccountDAO;
import com.team3.board.MemberDTO;


@WebServlet("/createAccount")
public class CreateAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CreateAccount() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	
	@SuppressWarnings("unused")
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String method = request.getMethod();
		System.out.println(method);

		String name = request.getParameter("name");
		String nickname = request.getParameter("nickname");
		String phone0 = request.getParameter("phone");
		String phone1 = request.getParameter("ph1");
		String phone2 = request.getParameter("ph2");
		String phone = phone0 + phone1 + phone2;
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String birth = request.getParameter("birth");
		String email = request.getParameter("email");
		
		
		System.out.println(name +" " + nickname +" " + phone + "_" + id + "_" + pw + "_" + birth + "_" + email);

		CreateAccountDAO dao = new CreateAccountDAO();
		MemberDTO dto = new MemberDTO();
		dto.setMember_id(id);
		dto.setMember_name(name);
		dto.setMember_nickname(nickname);
		dto.setMember_phone(phone);
		dto.setMember_pw(pw);
		dto.setMember_birth(birth);
		dto.setMember_email(email);
		dao.createAcoount(dto);
	}

}
