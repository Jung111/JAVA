package com.team3.web;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team3.board.MarketBoardDAO;
import com.team3.board.MarketBoardDTO;

@WebServlet("/marketsearch")
public class MarketSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public MarketSearch() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("./marketboard.jsp");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		String val = request.getParameter("search_val");
		MarketBoardDAO dao = new MarketBoardDAO();
		ArrayList<MarketBoardDTO> list = dao.searchlist(val);
		RequestDispatcher rd = request.getRequestDispatcher("./marketboard.jsp");
		request.setAttribute("search_val", val);
		request.setAttribute("list", list);
		rd.forward(request, response);
	}

}
