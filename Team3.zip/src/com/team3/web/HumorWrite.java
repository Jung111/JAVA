package com.team3.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.team3.board.HumorBoardDTO;
import com.team3.board.HumorBoardDAO;
import com.team3.util.FreeImgReSize;

@WebServlet("/humorwrite")
public class HumorWrite extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public HumorWrite() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("./humorwrite.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		HttpSession session = request.getSession();
		
		//경로
		String url = request.getSession().getServletContext().getRealPath("/");
		int maxSize = 1024 * 1024 * 10;
		
		String savePath = url + "upload\\";
		
		String uploadFile = "";
		String newFileName = null;
		
		MultipartRequest multi = 
				new MultipartRequest(request, savePath,
						maxSize, new DefaultFileRenamePolicy());
		
		String title = new String(multi.getParameter("title").getBytes("8859_1"),"UTF-8");
		String content = new String(multi.getParameter("content").getBytes("8859_1"),"UTF-8");
		
		//구분자-------------------------------
		
		if (session.getAttribute("member_no") != null 
				&& title != null 
				&& content != null
				&& !content.equals("<p><br></p>")) {
			
			long currentTime = System.currentTimeMillis();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

			if(multi.getFilesystemName("file") != null){
				uploadFile = multi.getFilesystemName("file");
				File oldFile = new File(savePath + uploadFile);
				newFileName = "";
				newFileName = sdf.format(new Date(currentTime)) + "."
						+ uploadFile.substring(uploadFile.lastIndexOf(".") + 1);
				
				File newFile = new File(savePath + newFileName);
				
				if(!oldFile.renameTo(newFile)) {
					byte[] buf = new byte[1024];
					FileInputStream fis = new FileInputStream(oldFile);
					FileOutputStream fos = new FileOutputStream(newFile);
					int read = 0;
					while ((read = fis.read(buf, 0, buf.length)) != -1) {
						fos.write(buf, 0, read);
					}	
				}
				oldFile.delete();
				
				FreeImgReSize.reSize(savePath, newFileName);
				
			}
			
			HumorBoardDTO dto = new HumorBoardDTO();
			dto.setHboard_title(title);
			dto.setHboard_content(content);
			dto.setHboard_file(newFileName);
			dto.setMember_no((int)session.getAttribute("member_no"));
			
			HumorBoardDAO dao = new HumorBoardDAO();
			dao.write(dto, "humorboard");
			RequestDispatcher rd = request.getRequestDispatcher("./humorboard");
			rd.forward(request, response);
		} else {
			response.sendRedirect("./humorboard");
		}
	}

}
