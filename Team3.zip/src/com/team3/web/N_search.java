package com.team3.web;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team3.board.NoticeDAO;
import com.team3.board.NoticeDTO;
import com.team3.util.NumberCheck;

@WebServlet("/n_search")
public class N_search extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public N_search() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("./noticeboard.jsp");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		int page = 1;
		if (request.getParameter("page") != null) {// 값이 있고, 그 값이 숫자라면
			// System.out.println("page" + request.getParameter("page"));
			page = NumberCheck.number(request.getParameter("page"));
		}
		String word = request.getParameter("w");
		NoticeDAO dao = new NoticeDAO();
		ArrayList<NoticeDTO> list = dao.search(word);
		RequestDispatcher rd = request.getRequestDispatcher("./noticeboard.jsp");
		request.setAttribute("w", word);
		request.setAttribute("count", list.size());
		request.setAttribute("page", page);
		request.setAttribute("noticeboard", list);
		rd.forward(request, response);
	}

}
