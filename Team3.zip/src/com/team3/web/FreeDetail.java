package com.team3.web;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team3.board.FreeBoardDAO;
import com.team3.board.FreeBoardDTO;
import com.team3.board.FreeCommentDTO;

@WebServlet("/freedetail")
public class FreeDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public FreeDetail() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fno = request.getParameter("fno");

		FreeBoardDAO dao = new FreeBoardDAO();
		FreeBoardDTO dto = dao.detail(Integer.parseInt(fno));
		
		request.setAttribute("dto", dto);

		if(dto.getComments() > 0) {
			ArrayList<FreeCommentDTO> comment = dao.comments(Integer.parseInt(fno));

			request.setAttribute("comment", comment);
		}
		
		
		RequestDispatcher rd = request.getRequestDispatcher("./freedetail.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("index.jsp");
	}

}
