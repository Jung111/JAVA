package com.team3.web;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team3.board.NoticeDAO;
import com.team3.board.NoticeDTO;

@WebServlet("/noticeboard")
public class NoticeBoard extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public NoticeBoard() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		NoticeDAO dao = new NoticeDAO();// Model
		ArrayList<NoticeDTO> list = dao.list();
		RequestDispatcher rd = request.getRequestDispatcher("/noticeboard.jsp"); // View
		request.setAttribute("noticeboard", list);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
