package com.team3.web;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team3.board.HumorBoardDTO;
import com.team3.board.HumorCommentDTO;
import com.team3.board.HumorBoardDAO;

@WebServlet("/humordetail")
public class HumorDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public HumorDetail() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String hno = request.getParameter("hno");

		HumorBoardDAO dao = new HumorBoardDAO();
		HumorBoardDTO dto = dao.detail(Integer.parseInt(hno));
		
		request.setAttribute("dto", dto);

		if(dto.getComments() > 0) {
			ArrayList<HumorCommentDTO> comment = dao.comments(Integer.parseInt(hno));

			request.setAttribute("comment", comment);
		}
		
		
		RequestDispatcher rd = request.getRequestDispatcher("./humordetail.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("index.jsp");
	}

}
