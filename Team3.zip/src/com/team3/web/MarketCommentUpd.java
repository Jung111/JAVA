package com.team3.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team3.board.MarketBoardDAO;
import com.team3.board.MarketCommentDTO;
import com.team3.util.FreeNumberCheck;

@WebServlet("/marketcommentupd")
public class MarketCommentUpd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public MarketCommentUpd() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		FreeNumberCheck check = new FreeNumberCheck();
		int mc_no = check.number(request.getParameter("mc_no"));
	
		MarketBoardDAO dao = new MarketBoardDAO();
		MarketCommentDTO dto = dao.commentpick(mc_no);
		RequestDispatcher rd = request.getRequestDispatcher("./marketcommentupd.jsp");
		request.setAttribute("dto", dto);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		FreeNumberCheck check = new FreeNumberCheck();
		int mc_no = check.number(request.getParameter("mc_no"));
		
		MarketBoardDAO dao = new MarketBoardDAO();
		MarketCommentDTO dto = new MarketCommentDTO();
		dto.setmc_no(mc_no);
		dto.setMcontent(request.getParameter("content"));
		
		dao.commentupdate(dto);
		response.sendRedirect("./marketdetail?mno="+request.getParameter("mno"));
	
	}

}
