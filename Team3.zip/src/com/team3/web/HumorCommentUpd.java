package com.team3.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team3.board.HumorBoardDAO;
import com.team3.board.HumorCommentDTO;
import com.team3.util.FreeNumberCheck;

@WebServlet("/humorcommentupd")
public class HumorCommentUpd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public HumorCommentUpd() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		FreeNumberCheck check = new FreeNumberCheck();
		int h_no = check.number(request.getParameter("h_no"));
	
		HumorBoardDAO dao = new HumorBoardDAO();
		HumorCommentDTO dto = dao.commentpick(h_no);
		RequestDispatcher rd = request.getRequestDispatcher("./humorcommentupd.jsp");
		request.setAttribute("dto", dto);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		FreeNumberCheck check = new FreeNumberCheck();
		int h_no = check.number(request.getParameter("h_no"));
		
		HumorBoardDAO dao = new HumorBoardDAO();
		HumorCommentDTO dto = new HumorCommentDTO();
		dto.setH_no(h_no);
		dto.setHcontent(request.getParameter("content"));
		
		dao.commentupdate(dto);
		response.sendRedirect("./humordetail?hno="+request.getParameter("hno"));
	}

}
