package com.team3.web;

import java.io.File;
import java.io.IOException;
import java.lang.ProcessBuilder.Redirect;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.team3.board.NoticeDAO;
import com.team3.board.NoticeDTO;
import com.team3.util.Dele;
import com.team3.util.NumberCheck;

@WebServlet("/n_delete")
public class N_Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public N_Delete() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println(request.getParameter("bno"));

		if (request.getParameter("bno") != null && NumberCheck.numberCh(request.getParameter("bno"))) {
			int bno = NumberCheck.number(request.getParameter("bno"));

			NoticeDAO dao = new NoticeDAO();
			String fileName = dao.findFile(bno);

			String url = request.getSession().getServletContext().getRealPath("/");
			String savePath = url + "upload\\";
			
			savePath = savePath + "/thumbnail/";
			Dele.fileDelete(savePath, fileName);

			dao.delete(bno, 1);
		}
		response.sendRedirect("./noticeboard");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
