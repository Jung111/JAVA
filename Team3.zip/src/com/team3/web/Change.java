package com.team3.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.team3.board.MemberDAO;

@WebServlet("/change")
public class Change extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Change() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		System.out.println(Integer.parseInt(request.getParameter("grade")));
		if (session.getAttribute("member_grade") != null && request.getParameter("no") != null
				&& session.getAttribute("member_grade").equals(9)) {

			int member_no = Integer.parseInt(request.getParameter("no"));
			int member_grade = Integer.parseInt(request.getParameter("grade"));
			MemberDAO dao = new MemberDAO();
			dao.change(member_grade, member_no);
			response.sendRedirect("./memberlist");
		} else {
			System.out.println(session.getAttribute("member_grade"));
			System.out.println(session.getAttribute("member_name"));
			System.out.println(session.getAttribute("member_id"));
			System.out.println(session.getAttribute("member_nickname"));
			System.out.println("안되요");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

}
