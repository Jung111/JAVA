package com.team3.web;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team3.board.MarketBoardDAO;
import com.team3.board.MarketBoardDTO;
import com.team3.board.MarketCommentDTO;

@WebServlet("/marketdetail")
public class MarketDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public MarketDetail() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String mno = request.getParameter("mno");

		MarketBoardDAO dao = new MarketBoardDAO();
		MarketBoardDTO dto = dao.detail(Integer.parseInt(mno));
		
		request.setAttribute("dto", dto);

		if(dto.getComments() > 0) {
			ArrayList<MarketCommentDTO> comment = dao.comments(Integer.parseInt(mno));

			request.setAttribute("comment", comment);
		}
		
		
		RequestDispatcher rd = request.getRequestDispatcher("./marketdetail.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("index.jsp");
	}

}
