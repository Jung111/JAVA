package com.team3.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.team3.board.FreeBoardDAO;
import com.team3.board.HumorBoardDAO;

@WebServlet("/humorcommentdel")
public class HumorCommentDel extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public HumorCommentDel() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//댓글 고유번호
		String h_no = request.getParameter("h_no");
		//게시글 고유번호
		String hno = request.getParameter("hno");
		
		String mno = request.getParameter("mno");
		HttpSession session = request.getSession();
		
		if (session.getAttribute("member_no").equals(Integer.parseInt(mno))) {
			
			HumorBoardDAO dao = new HumorBoardDAO();
			dao.humorcommentdel(h_no);
			response.sendRedirect("./humordetail?hno="+hno);
		} else {
			response.sendRedirect("./humordetail?hno="+hno);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
