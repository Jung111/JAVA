package com.team3.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.team3.board.NoticeDAO;
import com.team3.board.NoticeDTO;
import com.team3.util.ImgReSize;

@WebServlet("/n_write")
public class N_Write extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public N_Write() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("./n_write.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");

		// 파일경로
		String url = request.getSession().getServletContext().getRealPath("/");
		System.out.println("실제경로" + url);
		// url = "c:/workspace/Jan26_model2/WebContent/";

		// 파일크기
		int maxSize = 1024 * 1024 * 10; // 최대 10mb 초과하면 안올라가짐

		// 저장경로
		String savePath = url + "upload\\";

		// 업로드 파일명
		String uploadFile = "";

		// 실제 저장하는 파일명
		String newFileName = null;

		MultipartRequest multi = new MultipartRequest(request, savePath, maxSize, new DefaultFileRenamePolicy());
		String title = new String(multi.getParameter("title").getBytes("8859_1"), "UTF-8");
		String content = new String(multi.getParameter("content").getBytes("8859_1"), "UTF-8");
		// String file = new String(multi.getParameter("file").getBytes("8859_1"),
		// "UTF-8");

		long currenTime = System.currentTimeMillis();
		System.out.println(currenTime);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		System.out.println(sdf.format(new Date(currenTime)));
		// 추가: html의 <,> 막기
		if (multi.getFilesystemName("file") != null) {
			// 파일이 있을 경우에만 업로드 및 처리하기
			uploadFile = multi.getFilesystemName("file");
			// 업로드 된 파일 객체 생성하기
			File oldFile = new File(savePath + uploadFile);
			// 실제 저장될 파일 객체
			// 그 전에 이름 바꾸기
			newFileName = "";
			newFileName = sdf.format(new Date(currenTime)) + "."
					+ uploadFile.substring(uploadFile.lastIndexOf(".") + 1);

			File newFile = new File(savePath + newFileName);

			if (!oldFile.renameTo(newFile)) {
				byte[] buf = new byte[1024];
				FileInputStream fis = new FileInputStream(oldFile);
				FileOutputStream fos = new FileOutputStream(newFile);
				int read = 0;
				while ((read = fis.read(buf, 0, buf.length)) != -1) {
					fos.write(buf, 0, read);
				}
			}
			// old 파일 삭제하기
			oldFile.delete();
			System.out.println("서버에 저장할 경로:" + savePath);
			System.out.println("서버에 저장할 파일이름:" + newFileName);

			ImgReSize.reSize(savePath, newFileName);
		}
		NoticeDTO dto = new NoticeDTO();
		dto.setN_title(title);
		dto.setN_content(content);
		dto.setN_file(newFileName);
		// dto.setMember_name(name);
		dto.setMember_no(1);

		NoticeDAO dao = new NoticeDAO();
		dao.write(dto, "noticeboard");

		RequestDispatcher rd = request.getRequestDispatcher("./noticeboard");
		rd.forward(request, response);

	}

}
