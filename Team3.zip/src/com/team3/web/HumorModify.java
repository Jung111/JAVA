package com.team3.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.team3.board.HumorBoardDAO;
import com.team3.board.HumorBoardDTO;

@WebServlet("/humormodify")
public class HumorModify extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public HumorModify() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		if (session.getAttribute("member_no") != null && request.getParameter("hno") != null) {
			
			HumorBoardDAO dao = new HumorBoardDAO();
			HumorBoardDTO dto = dao.detail(Integer.parseInt(request.getParameter("hno")),(int)session.getAttribute("member_no"));

			if (dto.getMember_no() == (int)session.getAttribute("member_no")) {
				RequestDispatcher rd = request.getRequestDispatcher("./humormodify.jsp");
				request.setAttribute("dto", dto);
				rd.forward(request, response);
			} else {
				response.sendRedirect("./humorboard");
			}
		} else {
			response.sendRedirect("./humorboard");
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession();

		if(request.getParameter("hno") != null 
				&& request.getParameter("title") != null
				&& request.getParameter("content") != null 
				&& session.getAttribute("member_no") != null) {
			
			String hno = request.getParameter("hno");
			String title = request.getParameter("title");
			title = title.replaceAll("<", "&lt;");
			title = title.replaceAll(">", "&gt;");
			String content = request.getParameter("content");
			
			HumorBoardDTO dto = new HumorBoardDTO();
			dto.setHboard_no(Integer.parseInt(hno));
			dto.setHboard_title(title);
			dto.setHboard_content(content);
			dto.setMember_no((int)session.getAttribute("member_no"));
			
			HumorBoardDAO dao = new HumorBoardDAO();
			dao.humormodify(dto);
			
			response.sendRedirect("./humordetail?hno=" + hno);
			
		} else {
			response.sendRedirect("./humorboard");
			
		}
	}

}
