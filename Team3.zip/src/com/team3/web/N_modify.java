package com.team3.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team3.board.NoticeDAO;
import com.team3.board.NoticeDTO;

@WebServlet("/n_modify")
public class N_modify extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public N_modify() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		NoticeDAO dao = new NoticeDAO();
		NoticeDTO dto = dao.detail(Integer.parseInt(request.getParameter("bno")));
		request.setAttribute("dto4", dto);
		RequestDispatcher rd = request.getRequestDispatcher("./n_modify.jsp");
		rd.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
