package com.team3.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.team3.board.FreeBoardDAO;
import com.team3.db.DBConn;

@WebServlet("/freecommentdel")
public class FreeCommentDel extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public FreeCommentDel() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//댓글 고유번호
		String f_no = request.getParameter("f_no");
		//게시글 고유번호
		String fno = request.getParameter("fno");
		
		String mno = request.getParameter("mno");
		HttpSession session = request.getSession();
		
		if (session.getAttribute("member_no").equals(Integer.parseInt(mno))) {
			
			FreeBoardDAO dao = new FreeBoardDAO();
			dao.freecommentdel(f_no);
			response.sendRedirect("./freedetail?fno="+fno);
		} else {
			response.sendRedirect("./freedetail?fno="+fno);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
