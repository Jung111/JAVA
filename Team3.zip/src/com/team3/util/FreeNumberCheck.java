package com.team3.util;

public class FreeNumberCheck {
	// A123 -> 123
	public static int number(String str) {
		String temp = "";
		for (int i = 0; i < str.length(); i++) {
			//int num = str.charAt(i);
			if(Character.isDigit(str.charAt(i))) {
				temp += str.charAt(i);				
			}
		}
		return Integer.parseInt(temp);
	}

	// A123 -> 에러
	public static boolean numberCh(String str) {
		try {
			Integer.parseInt(str);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}
