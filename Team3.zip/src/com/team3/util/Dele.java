package com.team3.util;

import java.io.File;

public class Dele {
	public static void fileDelete(String url, String file) {
		File deleteFile = new File(file);
		if (deleteFile.exists()) {
			deleteFile.delete();
		}
	}
}
